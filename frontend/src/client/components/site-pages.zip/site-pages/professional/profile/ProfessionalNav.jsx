import React from "react";
import { Link } from "react-router-dom";


const ProfessionalNav = (props) => {

    return (
        <nav className="settings-tab mb-1">
            <ul className="nav nav-tabs-bottom" role="tablist">
                <li className="nav-item" role="presentation">
                    <Link className="nav-link active" to='/professional/myprofile'>
                        Profile
                    </Link>
                </li>
                <li className="nav-item" role="presentation">
                    <Link className="nav-link" to="/professional/license">
                        License
                    </Link>
                </li>
                <li className="nav-item" role="presentation">
                    <Link className="nav-link" to="/professional/certificate">
                        Certificate
                    </Link>
                </li>
                <li className="nav-item" role="presentation">
                    <Link className="nav-link" to="/professional/education">
                        Education
                    </Link>
                </li>
                <li className="nav-item" role="presentation">
                    <Link className="nav-link" to="/professional/reference">
                        Reference
                    </Link>
                </li>
                <li className="nav-item" role="presentation">
                    <Link className="nav-link" to="/professional/emergency">
                        Emergency contact
                    </Link>
                </li>
                <li className="nav-item" role="presentation">
                    <Link className="nav-link" to="/professional/change-password">
                        Change Password
                    </Link>
                </li>
            </ul>
        </nav>
    );
};

export default ProfessionalNav;
