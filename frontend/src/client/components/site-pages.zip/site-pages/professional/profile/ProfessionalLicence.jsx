import React, { useState, useEffect } from "react";
// import DashboardSidebar from "../sidebar/sidebar.jsx";
import DashboardSidebar from "../../../patients/dashboard/sidebar/sidebar.jsx";
// import IMG01 from "../../../../assets/images/patient.jpg";
import StickyBox from "react-sticky-box";
import { Link } from "react-router-dom";
import SiteFooter from "../../home/footer.jsx";
import SiteHeader from "../../home/header.jsx";
// import Header from "./header.jsx";
// import { DatePicker } from "antd";
import Select from "react-select";
import ImageWithBasePath from "../../../../../core/img/imagewithbasebath.jsx";
//import ImageWithBasePath from "../../core/img/imagewithbasebath.jsx";
import ProfessionalNav from "./ProfessionalNav.jsx";
import { API_BASE_URL, AUTH_TOKEN } from "../../config";
import { FaTimesCircle, FaPen } from "react-icons/fa";
import axios from "axios";
import DatePicker from 'react-datepicker';
import "react-datepicker/dist/react-datepicker.css";
import convertUrlToFile from "../../convertToFile";

const ProfessionalLicense = (props) => {
    const [licenses, setLicenses] = useState([]);
    const [error, setError] = useState(null);
    const currentUserID = atob(localStorage.getItem('RecordID')) || ""
    const prof_id = atob(localStorage.getItem('RecordID')) || "";
    const [isLoading, setIsLoading] = useState(false);
    const [updateForm, setUpdateForm] = useState(null);
    const [formErrors, setFormErrors] = useState({});

    {/* License add and update */}
    const [formData, setFormData] = useState({
        professional: prof_id,
        license_name: "",
        license_number: "",
        city: "",
        state: "",
        expired_on: "",
        license_file: null,
    });

    useEffect(() => {
        if (updateForm) {
            setFormData({
                ...updateForm,
                certificate_date: updateForm.certificate_date?.split('T')[0] || "",
            });
        }
    }, [updateForm]);


    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleFileChange = (e) => {
        console.log(e.target.files)
        setFormData({
            ...formData,
            license_file: e.target.files[0],
        });
    };

    const handleCancel = () => {
        setFormData({
            professional: prof_id,
            license_name: "",
            license_number: "",
            city: "",
            state: "",
            expired_on: "",
            license_file: null,
        });
        setUpdateForm(null);
        setFormErrors({})
    };

    const validiteFormInputs = (data) => {
      
        const errorObj = {};
        const emailRegx = /.+@.+\.[A-Za-z]+$/
        const phoneRegx = /\d/g
        if (Object.keys(data).length !== 0){
          if (data.license_name == '') {
            errorObj.license_name = "License name is required";
          }
  
          if (data.state == '') {
            errorObj.state = "State is required";
          }
  
          if (data.city == '') {
            errorObj.city = "City is required";
          }

          if (data.expired_on == '') {
            errorObj.expired_on = "Expire date is required";
          }
  
          if (data.license_number == '') {
            errorObj.license_number = "License number is required";
          }else if(!Number.isInteger(data.license_number)){
            errorObj.license_number = "Not a valid license number";
          }
  
          if (data.license_file == '') {
            errorObj.license_file = "File is required";
          }
        }
        return errorObj
    }

    const handleSubmit = async (e) => {
        e.preventDefault();
        const formValidate = validiteFormInputs(formData)
        if (Object.keys(formValidate).length === 0) {
            setIsLoading(true);
            setError(null);

            try {
                const formDataObj = new FormData();
                for (const key in formData) {
                    if (key === "license_file" && formData[key] && typeof formData[key] === 'string') {
                        console.log(formData[key].split('/').pop())
                        const file = await convertUrlToFile(formData[key], `license_${formData['id']}_${formData['license_name']}.png`);
                        formDataObj.append(key, file);
                    } else {
                        formDataObj.append(key, formData[key]);
                    }
                }

                //for create    
                let url = `${API_BASE_URL}/professional/CreateLicense/`;
                let method = "POST";

                //for update
                if (updateForm) {
                    url = `${API_BASE_URL}/professional/licenses/${updateForm.id}/`;
                    method = "PUT";
                }

                await axios({
                    method: method,
                    url: url,
                    data: formDataObj,
                    headers: { 
                        "Content-Type": "multipart/form-data",
                        'Authorization': AUTH_TOKEN
                    }
                });
                handleCancel();
                fetchLicenses();
            } catch (err) {
                console.log(err)
                setError(err.response?.data?.Result || "An error occurred");
            } finally {
                setIsLoading(false);
            }
        }else{
            setFormErrors(formValidate)
            return false;
        }
    };
    {/* License add and update */}

    {/*License list */}
    const fetchLicenses = async () => {
        try {
            const response = await axios.get(`${API_BASE_URL}/professional/licenses/?ProfID=${currentUserID}`,{
                headers: { 
                    "Content-Type": "application/json",
                    'Authorization': AUTH_TOKEN
                 },
            });
            setLicenses(response.data);
        } catch (err) {
            setError(err.response?.data?.Result || "An error occurred");
        }
    };

    const deleteLicense = async (id) => {
        try {
            await axios.delete(`${API_BASE_URL}/professional/licenses/${id}/`,{
                headers: { 
                    "Content-Type": "application/json",
                    'Authorization': AUTH_TOKEN
                },
            });
            setLicenses(licenses.filter((license) => license.id !== id));
        } catch (err) {
            setError(err.response?.data?.Result || "Error deleting license");
        }
    };

    const updateLicenses = async (id) => {
        const licenseToUpdate = licenses.find((license) => license.id === id);
        setUpdateForm(licenseToUpdate)
    }

    useEffect(() => {
        fetchLicenses();
    }, []);
    
    {/*License list */}

    return (
        <div>
            <SiteHeader />
            <>
                {/* Breadcrumb */}
                <div className="breadcrumb-bar">
                    <div className="container">
                        <div className="row align-items-center inner-banner">
                            <div className="col-md-12 col-12 text-center">
                                <nav aria-label="breadcrumb" className="page-breadcrumb">
                                    <ol className="breadcrumb">
                                        <li className="breadcrumb-item">
                                            <Link to="/home">
                                                <i className="isax isax-home-15" />
                                            </Link>
                                        </li>
                                        <li className="breadcrumb-item" aria-current="page">
                                            Professional
                                        </li>
                                        <li className="breadcrumb-item active">Profile</li>
                                    </ol>
                                    <h2 className="breadcrumb-title">License</h2>
                                </nav>
                            </div>
                        </div>
                    </div>
                    <div className="breadcrumb-bg">
                        <ImageWithBasePath
                            src="assets/img/bg/breadcrumb-bg-01.png"
                            alt="img"
                            className="breadcrumb-bg-01"
                        />
                        <ImageWithBasePath
                            src="assets/img/bg/breadcrumb-bg-02.png"
                            alt="img"
                            className="breadcrumb-bg-02"
                        />
                        <ImageWithBasePath
                            src="assets/img/bg/breadcrumb-icon.png"
                            alt="img"
                            className="breadcrumb-bg-03"
                        />
                        <ImageWithBasePath
                            src="assets/img/bg/breadcrumb-icon.png"
                            alt="img"
                            className="breadcrumb-bg-04"
                        />
                    </div>
                </div>
                {/* /Breadcrumb */}
            </>


            <div className="content">
                <div className="container">
                    <div className="row">
                        {/* <div className="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
                            <StickyBox offsetTop={20} offsetBottom={20}>
                                <DashboardSidebar />
                            </StickyBox>
                        </div> */}

                        <div className="col-lg-12 col-xl-12">
                                    <ProfessionalNav/>
                                    <div className="card">
                                        <div className="card-body">
                                            <div className="border-bottom pb-3 mb-3">
                                                <h5>License</h5>
                                            </div>
                                            <form onSubmit={handleSubmit}>
                                                <div className="setting-card">
                                                    <div className="row">
                                                        <div className="col-lg-4 col-md-6">
                                                            <div className="mb-3">
                                                                <label className="form-label">
                                                                    Licence Name {updateForm ? null : <span className="text-danger">*</span>}
                                                                </label>
                                                                <input
                                                                    type="text"
                                                                    name="license_name"
                                                                    className="form-control" 
                                                                    value={formData.license_name}
                                                                    onChange={handleInputChange}
                                                                    placeholder="Enter license name"
                                                                />
                                                                {formErrors.license_name && <div className="form-label text-danger m-1">{formErrors.license_name}</div>}
                                                            </div>
                                                        </div>
                                                        <div className="col-lg-4 col-md-6">
                                                            <div className="mb-3">
                                                                <label className="form-label">
                                                                    Licence Number {updateForm ? null : <span className="text-danger">*</span>}
                                                                </label>
                                                                <input
                                                                    type="text"
                                                                    name="license_number"
                                                                    className="form-control" 
                                                                    value={formData.license_number}
                                                                    onChange={handleInputChange}
                                                                    placeholder="Enter license number"
                                                                />
                                                                {formErrors.license_number && <div className="form-label text-danger m-1">{formErrors.license_number}</div>}
                                                            </div>
                                                        </div>
                                                        <div className="col-lg-4 col-md-6">
                                                            <div className="mb-3">
                                                                <label className="form-label">
                                                                    City {updateForm ? null : <span className="text-danger">*</span>}
                                                                </label>
                                                                <input
                                                                    type="text"
                                                                    name="city"
                                                                    className="form-control"
                                                                    value={formData.city}
                                                                    onChange={handleInputChange}
                                                                    placeholder="Enter city"
                                                                />
                                                                {formErrors.city && <div className="form-label text-danger m-1">{formErrors.city}</div>}
                                                            </div>
                                                        </div>
                                                        <div className="col-lg-4 col-md-6">
                                                            <div className="mb-3">
                                                                <label className="form-label">
                                                                    State {updateForm ? null : <span className="text-danger">*</span>}
                                                                </label>
                                                                <input
                                                                    type="text"
                                                                    name="state"
                                                                    className="form-control"
                                                                    value={formData.state}
                                                                    onChange={handleInputChange}
                                                                    placeholder="Enter state"
                                                                />
                                                                {formErrors.state && <div className="form-label text-danger m-1">{formErrors.state}</div>}
                                                            </div>
                                                        </div>
                                                        <div className="col-lg-4 col-md-6">
                                                            <div className="form-wrap">
                                                                <label className="col-form-label">
                                                                    Expire Date {updateForm ? null : <span className="text-danger">*</span>}
                                                                </label>
                                                            <div className="form-icon">
                                                                <DatePicker
                                                                    className="form-control datetimepicker"
                                                                    name="expired_on"
                                                                    selected={formData.expired_on} 
                                                                    onChange={(date) =>setFormData({ ...formData, expired_on : date.toISOString().split('T')[0]})}
                                                                    dateFormat="MM/dd/yyyy"
                                                                    placeholderText="MM:DD:YYY"
                                                                    showDayMonthYearPicker
                                                                />
                                                                <span className="icon">
                                                                <i className="fa-regular fa-calendar-days" />
                                                                </span>
                                                            </div>
                                                            {formErrors.expired_on && <div className="form-label text-danger m-1">{formErrors.expired_on}</div>}
                                                            </div>
                                                        </div>
                                                        <div className="col-lg-4 col-md-6">
                                                            <div className="mb-3">
                                                                <label className="form-label">
                                                                File {updateForm ? null : <span className="text-danger">*</span>}
                                                                </label>
                                                                {updateForm ? (
                                                                    <>
                                                                    {formData.license_file && typeof formData.license_file === 'string' ? (
                                                                        <div style={{marginTop:"5px"}}>
                                                                            <label>Currently:</label>
                                                                            <a href={formData.license_file} target="_blank" rel="noopener noreferrer">
                                                                                {formData.license_file.split("/").pop()}
                                                                            </a>
                                                                            <button 
                                                                                type="button" 
                                                                                className="btn btn-danger m-1" 
                                                                                onClick={() => setFormData({ ...formData, license_file: "" })}
                                                                            >
                                                                                Delete
                                                                            </button>
                                                                        </div>
                                                                    ) : null}
                                                                    </>
                                                                ):null}
                                                                <input
                                                                    type="file"
                                                                    name="license_file"
                                                                    className="form-control"
                                                                    onChange={handleFileChange}
                                                                />
                                                                {formErrors.license_file && <div className="form-label text-danger m-1">{formErrors.license_file}</div>}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>



                                                <div className="modal-btn text-end">
                                                    <Link to="#" className="btn btn-md btn-light rounded-pill" onClick={handleCancel}>
                                                        Cancel
                                                    </Link>
                                                    <button
                                                        type="submit"
                                                        className="btn btn-md btn-primary-gradient rounded-pill"
                                                    >
                                                        {updateForm ? "Save Changes" : "Submit"}
                                                    </button>
                                                </div>

                                                {/* Medical Records Tab */}
                                                <div className="">
                                                    <div className="search-header">
                                                        <div className="search-field">
                                                            <input
                                                                type="text"
                                                                className="form-control"
                                                                placeholder="Search"
                                                            />
                                                            <span className="search-icon">
                                                                <i className="fa-solid fa-magnifying-glass" />
                                                            </span>
                                                        </div>

                                                    </div>
                                                    <div className="custom-table">
                                                        <div className="table-responsive">
                                                            <table className="table table-center mb-0">
                                                                <thead>
                                                                    <tr>
                                                                        <th>License Name</th>
                                                                        <th>License Number</th>
                                                                        <th>City</th>
                                                                        <th>State</th>
                                                                        <th>Action</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    {licenses.length === 0 ? 
                                                                        <tr><td colSpan={5}>No license data found for this professional</td></tr>
                                                                    :
                                                                    licenses.map((license) => (
                                                                        <tr key={license.id}>
                                                                            <td>{license.license_name}</td>
                                                                            <td>{license.license_number}</td>
                                                                            <td>{license.city}</td>
                                                                            <td>{license.state}</td>
                                                                            <td>
                                                                                <div className="action-item">
                                                                                    <Link to="#" onClick={() => updateLicenses(license.id)}>
                                                                                        <i className="isax isax-edit-2" />
                                                                                    </Link>
                                                                                    {/* <Link to="#">
                                                                                        <i className="isax isax-import" />
                                                                                    </Link> */}
                                                                                    <Link to="#" onClick={() => deleteLicense(license.id)}>
                                                                                        <i className="isax isax-trash" />
                                                                                    </Link>
                                                                                </div>
                                                                            </td>
                                                                            {/* <td>
                                                                                <FaPen style={{color:"blue", padding:"8px", fontSize:"20px"}} onClick={() => updateLicenses(license.id)}/>
                                                                                <FaTimesCircle style={{color:"red", padding:"8px", fontSize:"20px"}} onClick={() => deleteLicense(license.id)}/>
                                                                            </td> */}
                                                                        </tr>
                                                                    ))}
                                                                </tbody>
                                                                {/* <tbody>
                                                                    <tr>
                                                                        <td>Cerified Nurse</td>
                                                                        <td>12345</td>
                                                                        <td>Arizona</td>
                                                                        <td>Arizona</td>
                                                                        <td>
                                                                            <div className="action-item">
                                                                                <Link
                                                                                    to="#"
                                                                                    data-bs-toggle="modal"
                                                                                    data-bs-target="#edit_medical_records"
                                                                                >
                                                                                    <i className="isax isax-edit-2" />
                                                                                </Link>
                                                                                <Link to="#">
                                                                                    <i className="isax isax-import" />
                                                                                </Link>
                                                                                <Link to="#">
                                                                                    <i className="isax isax-trash" />
                                                                                </Link>
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                    
                                                                    <tr>
                                                                        <td>Cerified Physician</td>
                                                                        <td>54321</td>
                                                                        <td>Naveda</td>
                                                                        <td>Naveda</td>
                                                                        <td>
                                                                            <div className="action-item">
                                                                                <Link
                                                                                    to="#"
                                                                                    data-bs-toggle="modal"
                                                                                    data-bs-target="#edit_medical_records"
                                                                                >
                                                                                    <i className="isax isax-edit-2" />
                                                                                </Link>
                                                                                <Link to="#">
                                                                                    <i className="isax isax-import" />
                                                                                </Link>
                                                                                <Link to="#">
                                                                                    <i className="isax isax-trash" />
                                                                                </Link>
                                                                            </div>
                                                                        </td>                                                                    
                                                                    </tr>
                                                                </tbody> */}
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                                {/* /Medical Records Tab */}

                                            </form>
                                        </div>
                                    </div>
                        </div>
                    </div>
                </div>
            </div>
            <SiteFooter />
        </div>
    );
};

export default ProfessionalLicense;
