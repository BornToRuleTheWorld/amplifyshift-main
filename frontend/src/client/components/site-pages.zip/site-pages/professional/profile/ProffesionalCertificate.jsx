import React, { useState, useEffect } from "react";
// import DashboardSidebar from "../sidebar/sidebar.jsx";
import DashboardSidebar from "../../../patients/dashboard/sidebar/sidebar.jsx";
// import IMG01 from "../../../../assets/images/patient.jpg";
import StickyBox from "react-sticky-box";
import { Link } from "react-router-dom";
import SiteFooter from "../../home/footer.jsx";
import SiteHeader from "../../home/header.jsx";
// import Header from "./header.jsx";
// import { DatePicker } from "antd";
import Select from "react-select";
import ImageWithBasePath from "../../../../../core/img/imagewithbasebath.jsx";
//import ImageWithBasePath from "../../core/img/imagewithbasebath.jsx";
import ProfessionalNav from "./ProfessionalNav.jsx";
import axios from "axios";
import { FaTimesCircle, FaPen } from "react-icons/fa";
import { API_BASE_URL, AUTH_TOKEN} from "../../config";
import DatePicker from 'react-datepicker';
import "react-datepicker/dist/react-datepicker.css";
import convertUrlToFile from "../../convertToFile";

const ProfessionalCertificate = (props) => {

    const [certificates, setCertificates] = useState([]);
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [updateForm, setUpdateForm] = useState(null);
    const currentUserID = atob(localStorage.getItem('RecordID')) || "";
    const [formErrors, setFormErrors] = useState({});

    {/* Certificate add and update */}
    const [formData, setFormData] = useState({
        professional: currentUserID,
        certificate_name: "",
        certificate_date: "",
        city: "",
        state: "",
        country: "",
        certificate_file: null,
    });

    useEffect(() => {
        if (updateForm) {
            setFormData({
                ...updateForm,
                certificate_date: updateForm.certificate_date?.split('T')[0] || "",
            });
        }
    }, [updateForm]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleFileChange = (e) => {
        setFormData({
            ...formData,
            certificate_file: e.target.files[0],
        });
    };

    const handleCancel = () => {
        setFormData({
            professional: currentUserID,
            certificate_name: "",
            certificate_date: "",
            city: "",
            state: "",
            country: "",
            certificate_file: null,
        });
        setUpdateForm(null);
        setFormErrors({})
    };

    const validiteFormInputs = (data) => {
      
        const errorObj = {};
        const emailRegx = /.+@.+\.[A-Za-z]+$/
        const phoneRegx = /\d/g
        
        if (Object.keys(data).length !== 0){
          if (data.certificate_name == '') {
            errorObj.certificate_name = "Certificate name is required";
          }
  
          if (data.certificate_date == '') {
            errorObj.certificate_date = "Certificate date is required";
          }
  
          if (data.city == '') {
            errorObj.city = "City is required";
          }

          if (data.state == '') {
            errorObj.state = "State is required";
          }

          if (data.country == '') {
            errorObj.country = "Country is required";
          }
  
          if (data.certificate_file == '') {
            errorObj.certificate_file = "File is required";
          }
        }
        return errorObj
    }


    const handleSubmit = async (e) => {
        e.preventDefault();
        const formValidate = validiteFormInputs(formData)
        if (Object.keys(formValidate).length === 0) {
            setIsLoading(true);
            setError(null);

            try {
                const formDataObj = new FormData();
                for (const key in formData) {
                    if (key === "certificate_file" && formData[key] && typeof formData[key] === 'string') {
                        console.log(formData[key].split('/').pop())
                        const file = await convertUrlToFile(formData[key], `certificate_${formData['id']}_${formData['certificate_name']}.png`);
                        formDataObj.append(key, file);
                    } else {
                        formDataObj.append(key, formData[key]);
                    }
                }

                //for create    
                let url = `${API_BASE_URL}/professional/certifications/`;
                let method = "POST";

                //for update
                if (updateForm) {
                    url = `${API_BASE_URL}/professional/certifications/${updateForm.id}/`;
                    method = "PUT";
                }

                await axios({
                    method: method,
                    url: url,
                    data: formDataObj,
                    headers: { 
                        "Content-Type": "multipart/form-data",
                        'Authorization': AUTH_TOKEN
                    }
                });
                handleCancel();
                fetchCertificates();
            } catch (err) {
                console.log(err)
                setError(err.response?.data?.Result || "An error occurred");
            } finally {
                setIsLoading(false);
            }
        }else{
            setFormErrors(formValidate)
            return false;
        }
    };
    {/* Certificate add and update */}

    {/* Certificate List*/}
    const fetchCertificates = async () => {
        setError(null);
        try {
            const response = await axios.get(`${API_BASE_URL}/professional/certifications/?ProfID=${currentUserID}`,{
                headers: { 
                    "Content-Type": "application/json",
                    'Authorization': AUTH_TOKEN
                 },
            });
            setCertificates(response.data);
        } catch (err) {
            setError(err.response?.data?.Result || "An error occurred");
        }
    };

    const deleteCertificates = async (id) => {
        setError(null);
        try {
            await axios.delete(`${API_BASE_URL}/professional/certifications/${id}/`,{
                headers: { 
                    "Content-Type": "application/json",
                    'Authorization': AUTH_TOKEN
                },
            });
            setCertificates(certificates.filter((certificate) => certificate.id !== id));
        } catch (err) {
            setError(err.response?.data?.Result || "Error deleting certificate");
        }
    };

    const updateCertificates = async (id) => {
        const certificateToUpdate = certificates.find((certificate) => certificate.id === id);
        setUpdateForm(certificateToUpdate)
    }

    useEffect(() => {
        fetchCertificates();
    }, []);

    {/* Certificate List*/}
    return (
        <div>
            <SiteHeader />
            <>
                {/* Breadcrumb */}
                <div className="breadcrumb-bar">
                    <div className="container">
                        <div className="row align-items-center inner-banner">
                            <div className="col-md-12 col-12 text-center">
                                <nav aria-label="breadcrumb" className="page-breadcrumb">
                                    <ol className="breadcrumb">
                                        <li className="breadcrumb-item">
                                            <Link to="/home">
                                                <i className="isax isax-home-15" />
                                            </Link>
                                        </li>
                                        <li className="breadcrumb-item" aria-current="page">
                                            Professional
                                        </li>
                                        <li className="breadcrumb-item active">Profile</li>
                                    </ol>
                                    <h2 className="breadcrumb-title">Certificate</h2>
                                </nav>
                            </div>
                        </div>
                    </div>
                    <div className="breadcrumb-bg">
                        <ImageWithBasePath
                            src="assets/img/bg/breadcrumb-bg-01.png"
                            alt="img"
                            className="breadcrumb-bg-01"
                        />
                        <ImageWithBasePath
                            src="assets/img/bg/breadcrumb-bg-02.png"
                            alt="img"
                            className="breadcrumb-bg-02"
                        />
                        <ImageWithBasePath
                            src="assets/img/bg/breadcrumb-icon.png"
                            alt="img"
                            className="breadcrumb-bg-03"
                        />
                        <ImageWithBasePath
                            src="assets/img/bg/breadcrumb-icon.png"
                            alt="img"
                            className="breadcrumb-bg-04"
                        />
                    </div>
                </div>
                {/* /Breadcrumb */}
            </>


            <div className="content">
                <div className="container">
                    <div className="row">
                        {/* <div className="col-md-5 col-lg-4 col-xl-3 theiaStickySidebar">
                            <StickyBox offsetTop={20} offsetBottom={20}>
                                <DashboardSidebar />
                            </StickyBox>
                        </div> */}

                        <div className="col-lg-12 col-xl-12">
                                    <ProfessionalNav/>
                                    <div className="card">
                                        <div className="card-body">
                                            <div className="border-bottom pb-3 mb-3">
                                                <h5>Certificate</h5>
                                            </div>
                                            <form onSubmit={handleSubmit}>
                                                <div className="setting-card">
                                                    <div className="row">
                                                        <div className="col-lg-4 col-md-6">
                                                            <div className="mb-3">
                                                                <label className="form-label">
                                                                    Certificate Name <span className="text-danger">*</span>
                                                                </label>
                                                                <input
                                                                    type="text"
                                                                    name="certificate_name"
                                                                    className="form-control"
                                                                    value={formData.certificate_name}
                                                                    onChange={handleInputChange}
                                                                    placeholder="Enter certificate name"
                                                                />
                                                                {formErrors.certificate_name && <div className="form-label text-danger m-1">{formErrors.certificate_name}</div>}
                                                            </div>
                                                        </div>
                                                        <div className="col-lg-4 col-md-6">
                                                            <div className="form-wrap">
                                                                <label className="col-form-label">
                                                                Certificate Date <span className="text-danger">*</span>
                                                                </label>
                                                            <div className="form-icon">
                                                                <DatePicker
                                                                    className="form-control datetimepicker"
                                                                    name="certificate_date"
                                                                    selected={formData.certificate_date}
                                                                    onChange={(date) =>setFormData({ ...formData, certificate_date : date.toISOString().split('T')[0]})}
                                                                    dateFormat="MM/dd/yyyy"
                                                                    placeholderText="MM:DD:YYY"
                                                                    showDayMonthYearPicker
                                                                     
                                                                />
                                                                <span className="icon">
                                                                <i className="fa-regular fa-calendar-days" />
                                                                </span>
                                                            </div>
                                                            {formErrors.certificate_date && <div className="form-label text-danger m-1">{formErrors.certificate_date}</div>}
                                                            </div>
                                                        </div>
                                                        <div className="col-lg-4 col-md-6">
                                                            <div className="mb-3">
                                                                <label className="form-label">
                                                                    City <span className="text-danger">*</span>
                                                                </label>
                                                                <input
                                                                    type="text"
                                                                    name="city"
                                                                    className="form-control"
                                                                    value={formData.city}
                                                                    onChange={handleInputChange}
                                                                    placeholder="Enter city"
                                                                />
                                                                {formErrors.city && <div className="form-label text-danger m-1">{formErrors.city}</div>}
                                                            </div>
                                                        </div>
                                                        <div className="col-lg-4 col-md-6">
                                                            <div className="mb-3">
                                                                <label className="form-label">
                                                                    State <span className="text-danger">*</span>
                                                                </label>
                                                                <input
                                                                    type="text"
                                                                    name="state"
                                                                    className="form-control"
                                                                    value={formData.state}
                                                                    onChange={handleInputChange}
                                                                    placeholder="Enter state"
                                                                />
                                                                {formErrors.state && <div className="form-label text-danger m-1">{formErrors.state}</div>}
                                                            </div>
                                                        </div>
                                                        <div className="col-lg-4 col-md-6">
                                                            <div className="mb-3">
                                                                <label className="form-label">
                                                                    Country <span className="text-danger">*</span>
                                                                </label>
                                                                <input
                                                                    type="text"
                                                                    name="country"
                                                                    className="form-control"
                                                                    value={formData.country}
                                                                    onChange={handleInputChange}
                                                                    placeholder="Enter country"
                                                                />
                                                                {formErrors.country && <div className="form-label text-danger m-1">{formErrors.country}</div>}
                                                            </div>
                                                        </div>
                                                        <div className="col-lg-4 col-md-6">
                                                            <div className="mb-3">
                                                                <label className="form-label">
                                                                Certificate File <span className="text-danger">*</span>
                                                                </label>
                                                                {updateForm ? (
                                                                <>
                                                                {formData.certificate_file && typeof formData.certificate_file === 'string' ? (
                                                                    <div className="mt-1">
                                                                        <label>Currently: </label>
                                                                        <a href={formData.certificate_file} target="_blank" rel="noopener noreferrer">
                                                                            {formData.certificate_file.split("/").pop()}
                                                                        </a>
                                                                        <button 
                                                                            type="button" 
                                                                            className="btn btn-danger m-1" 
                                                                            onClick={() => setFormData({ ...formData, certificate_file: "" })}
                                                                        >
                                                                            Delete
                                                                        </button>
                                                                    </div>
                                                                ) : null}
                                                                </>
                                                            ):null}
                                                                <input
                                                                    type="file"
                                                                    name="certificate_file"
                                                                    className="form-control"
                                                                    onChange={handleFileChange}
                                                                />
                                                                {formErrors.certificate_file && <div className="form-label text-danger m-1">{formErrors.certificate_file}</div>}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>



                                                <div className="modal-btn text-end">
                                                    <Link to="#" className="btn btn-md btn-light rounded-pill" onClick={handleCancel}>
                                                        Cancel
                                                    </Link>
                                                    <button
                                                        type="submit"
                                                        className="btn btn-md btn-primary-gradient rounded-pill"
                                                    >
                                                        {updateForm ? "Save Changes" : "Submit"}
                                                    </button>
                                                </div>

                                                {/* Medical Records Tab */}
                                                <div className="">
                                                    <div className="search-header">
                                                        <div className="search-field">
                                                            <input
                                                                type="text"
                                                                className="form-control"
                                                                placeholder="Search"
                                                            />
                                                            <span className="search-icon">
                                                                <i className="fa-solid fa-magnifying-glass" />
                                                            </span>
                                                        </div>

                                                    </div>
                                                    <div className="custom-table">
                                                        <div className="table-responsive">
                                                            <table className="table table-center mb-0">
                                                                <thead>
                                                                    <tr>
                                                                        <th>Certificate Name</th>
                                                                        <th>Certificate Date</th>
                                                                        <th>City</th>
                                                                        <th>State</th>
                                                                        <th>Action</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    {certificates.length === 0 ?
                                                                        <tr><td colSpan={7}>No certificate data found for this professional</td></tr>
                                                                    :
                                                                    certificates.map((certificate) => (
                                                                        <tr key={certificate.id}>
                                                                            <td>{certificate.certificate_name}</td>
                                                                            <td>{new Date(certificate.certificate_date).toLocaleDateString()}</td>
                                                                            <td>{certificate.city}</td>
                                                                            <td>{certificate.state}</td>
                                                                            <td>
                                                                                <div className="action-item">
                                                                                    <Link to="#" onClick={() => updateCertificates(certificate.id)}>
                                                                                        <i className="isax isax-edit-2" />
                                                                                    </Link>
                                                                                    {/* <Link to="#">
                                                                                        <i className="isax isax-import" />
                                                                                    </Link> */}
                                                                                    <Link to="#" onClick={() => deleteCertificates(certificate.id)}>
                                                                                        <i className="isax isax-trash" />
                                                                                    </Link>
                                                                                </div>
                                                                            </td>
                                                                        </tr>
                                                                    ))}
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                                {/* /Medical Records Tab */}

                                            </form>
                                        </div>
                                    </div>
                        </div>
                    </div>
                </div>
            </div>
            <SiteFooter />
        </div>
    );
};

export default ProfessionalCertificate;
