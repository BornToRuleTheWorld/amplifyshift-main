import React, { useState } from 'react'
import { Link } from "react-router-dom";
import axios from "axios";
import Select from "react-select";
import { Calendar, theme } from 'antd';
import SiteHeader from '../home/header';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { API_BASE_URL, AUTH_TOKEN, workSettingOptions, jobTypeOptions,disciplineOptions, specialtyOptions, yearOptions, boolOption, langOptions, visitType, stateOptions, cntryOptions} from "../config";
import { useHistory } from 'react-router-dom';

const onPanelChange = (value, mode) => {
  console.log(value.format('YYYY-MM-DD'), mode);
};
const JobRegistration = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const history = useHistory();
  const facID = atob(localStorage.getItem('RecordID')) || "";
  const currentUser = atob(localStorage.getItem('userID')) || "";
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [formErrors, setFormErrors] = useState({});
  const [formData, setFormData] = useState({
      job_title: "",
      facility: facID,
      discipline:"",
      years_of_exp: "",
      speciality: "",
      license: "",
      work_setting: "",
      job_type: "",
      languages:"",
      visit_type:"",
      pay:"",
      cpr_bls:"",
      contact_person:"",
      address1:"",
      address2:"",
      city:"",
      state:"",
      country:"",
      zipcode:"",
      created_by:currentUser,
      start_date:"",
      end_date:"",
      contact_phone:"",
      status:"Inactive"
  });

  const { token } = theme.useToken();
  const wrapperStyle = {
    width: '100%',
    border: `1px solid ${token.colorBorderSecondary}`,
    borderRadius: token.borderRadiusLG,
  };
  const handleNext = () => {
    setCurrentStep(currentStep + 1);
  };

  const handlePrev = () => {
    setCurrentStep(currentStep - 1);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
        ...formData,
        [name]: value,
    });
  };

  const validiteFormInputs = (data) => {
      
    const errorObj = {};
    const phoneRegx = /\d/g

      if (data.start_date == '') {
        errorObj.start_date = "Start date is required";
      }

      if (data.end_date == '') {
        errorObj.end_date = "End date is required";
      }

      if (data.job_title == '') {
        errorObj.job_title = "Title is required";
      }

      if (data.discipline == '') {
        errorObj.discipline = "Please choose a discipline";
      }

      if (data.years_of_exp == '') {
        errorObj.years_of_exp = "Please choose a experience";
      }

      if (data.speciality == '') {
        errorObj.speciality = "Please choose a speciality";
      }

      if (data.work_setting == '') {
        errorObj.work_setting = "Please choose a work setting";
      }

      if (data.job_type == '') {
        errorObj.job_type = "Please choose a job type";
      }

      if (data.languages == '') {
        errorObj.languages = "Please choose a language";
      }

      if (data.visit_type == '') {
        errorObj.visit_type = "Please choose a visit type";
      }

      if (data.state == '') {
        errorObj.state = "Please choose a state";
      }

      if (data.country == '') {
        errorObj.country = "Please choose an country";
      }

      if (data.contact_phone == '') {
        errorObj.contact_phone = "Contact is required";
      }

      if (data.contact_phone != '') {
        if (!phoneRegx.test(data.contact_phone)) {
          errorObj.contact_phone = "Invalid contact number";
        }
      }
      
      if (data.contact_person == '') {
        errorObj.contact_person = "Contact person is required";
      }

      if (data.address1 == '') {
        errorObj.address1 = "Address1 is required";
      }

      if (data.city == '') {
        errorObj.city = "City is required";
      }

      if (data.zipcode == '') {
        errorObj.zipcode = "Zipcode is required";
      }

      if (data.pay == '') {
        errorObj.pay = "Pay is required";
      }
  
    return errorObj
  }

const handleSubmit = async (e) => {
  e.preventDefault();
  const formValidate = validiteFormInputs(formData)
  if (Object.keys(formValidate).length === 0) {
    setIsLoading(true);
    setError(null);

    try {
        let url = `${API_BASE_URL}/jobs/CreateJobs/`;
        let method = "POST";

        const response = await axios({
            method: method,
            url: url,
            data: formData,
            headers: { 
                "Content-Type": "application/json",
                'Authorization': AUTH_TOKEN
            }
        });
        localStorage.setItem('facJobID',btoa(response.data.JobID))
        // handleNext();
        history.push('/facility/job-work-hours')
      } catch (err) {
          console.log(err)
          setError(err.response?.data?.Result || "An error occurred");
      } finally {
          setIsLoading(false);
      }
    }else{
      setFormErrors(formValidate)
      return false;
    }
  };

  return (
  <div classname="main-wrapper">
  <SiteHeader />
  <div className="doctor-content">
    <div className="container">
      <div className="row">
        <div className="col-lg-9 mx-auto">
          <div className="booking-wizard">
            <ul
              className="form-wizard-steps d-sm-flex align-items-center justify-content-center"
              id="progressbar2"
            >
              <li className={
                      currentStep === 1
                        ? 'progress-active'
                        : currentStep > 1
                        ? 'progress-activated'
                        : ''
                    }>
                <div className="profile-step">
                  <span className="multi-steps">1</span>
                  <div className="step-section">
                    <h6>Job</h6>
                  </div>
                </div>
              </li>
              <li className={
                      currentStep === 2
                        ? 'progress-active'
                        : currentStep > 2
                        ? 'progress-activated'
                        : ''
                    }>
                <div className="profile-step">
                  <span className="multi-steps">2</span>
                  <div className="step-section">
                    <h6>Job Work Hours</h6>
                  </div>
                </div>
              </li>
              
              <li className={
                      currentStep === 3
                        ? 'progress-active'
                        : currentStep > 3
                        ? 'progress-activated'
                        : ''
                    }>
                <div className="profile-step">
                  <span className="multi-steps">3</span>
                  <div className="step-section">
                    <h6>Confirmation</h6>
                  </div>
                </div>
              </li>
            </ul>
          </div>
          <div className="booking-widget multistep-form mb-5">
          {currentStep === 1 && (
            <form onSubmit={handleSubmit} >
            <fieldset id="first">
              <div className="card booking-card mb-0">
                <div className="card-header">
                  <h3>Job Registration</h3>
                </div>
                <div className="card-body booking-body">
                  <div className="card mb-0">
                    <div className="card-body pb-1">
                      <div className="row">
                        <div className="col-lg-4 col-md-6">
                          <div className="form-wrap">
                            <label className="col-form-label">
                              Start Date <span className="text-danger">*</span>
                            </label>
                            <div className="form-icon">
                            <DatePicker
                            className="form-control datetimepicker"
                            name="start_date"
                            selected={formData.start_date}
                            onChange={(date) => setFormData({...formData, start_date: date})}
                            dateFormat="dd/MM/yyyy"
                            showDayMonthYearPicker
                            />
                              <span className="icon">
                                <i className="fa-regular fa-calendar-days" />
                              </span>
                            </div>
                            {formErrors.start_date && <div className="form-label text-danger m-1">{formErrors.start_date}</div>}
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                          <div className="form-wrap">
                            <label className="col-form-label">
                              End Date <span className="text-danger">*</span>
                            </label>
                            <div className="form-icon">
                            <DatePicker
                            className="form-control datetimepicker"
                            name="end_date"
                            selected={formData.end_date}
                            onChange={(date) => setFormData({...formData, end_date: date})}
                            dateFormat="dd/MM/yyyy"
                            showDayMonthYearPicker
                          />
                              <span className="icon">
                                <i className="fa-regular fa-calendar-days" />
                              </span>
                            </div>
                            {formErrors.end_date && <div className="form-label text-danger m-1">{formErrors.end_date}</div>}
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                          <div className="mb-3">
                            <label className="form-label">Job Title <span className="text-danger">*</span></label>
                            <input type="text" name="job_title" value={formData.job_title} onChange={handleInputChange} className="form-control" />
                            {formErrors.job_title && <div className="form-label text-danger m-1">{formErrors.job_title}</div>}
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                          <div className="mb-3">
                            <label className="form-label">Select Work Experience <span className="text-danger">*</span></label>
                            
                            <Select
                              className="select"
                              name="years_of_exp"
                              options={yearOptions}
                              value={yearOptions.find(option => option.value == formData.years_of_exp)}
                              onChange={(selected) => setFormData({...formData, years_of_exp: selected.value})}
                              placeholder="Select"
                              isClearable={true}
                              isSearchable={true}
                            />
                            {formErrors.years_of_exp && <div className="form-label text-danger m-1">{formErrors.years_of_exp}</div>}
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                          <div className="mb-3">
                            <label className="form-label">Select Discipline <span className="text-danger">*</span></label>
                            
                            <Select
                              className="select"
                              name = "discipline"
                              options={disciplineOptions}
                              value={disciplineOptions.find(option => option.value == formData.discipline)}
                              onChange={(selected) => setFormData({...formData, discipline: selected.value})}
                              placeholder="Select"
                              isClearable={true}
                              isSearchable={true}
                            />
                            {formErrors.discipline && <div className="form-label text-danger m-1">{formErrors.discipline}</div>}
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                          <div className="mb-3">
                            <label className="form-label">Select Specialty <span className="text-danger">*</span></label>
                            
                            <Select
                              className="select"
                              name="speciality"
                              options={specialtyOptions}
                              value={specialtyOptions.find(option => option.value == formData.speciality)}
                              onChange={(selected) => setFormData({...formData, speciality: selected.value})}
                              placeholder="Select"
                              isClearable={true}
                              isSearchable={true}
                            />
                            {formErrors.speciality && <div className="form-label text-danger m-1">{formErrors.speciality}</div>}
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                          <div className="mb-3">
                            <label className="form-label">Select Work Setting <span className="text-danger">*</span></label>
                            
                            <Select
                              className="select"
                              name = "work_setting"
                              options={workSettingOptions}
                              value={workSettingOptions.find(option => option.value == formData.work_setting)}
                              onChange={(selected) => setFormData({...formData, work_setting: selected.value})}
                              placeholder="Select"
                              isClearable={true}
                              isSearchable={true}
                            />
                            {formErrors.work_setting && <div className="form-label text-danger m-1">{formErrors.work_setting}</div>}
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                          <div className="mb-3">
                            <label className="form-label">Select Job Type <span className="text-danger">*</span></label>
                            
                            <Select
                              className="select"
                              name="job_type"
                              options={jobTypeOptions}
                              value={jobTypeOptions.find(option => option.value == formData.job_type)}
                              onChange={(selected) => setFormData({...formData, job_type: selected.value})}
                              placeholder="Select"
                              isClearable={true}
                              isSearchable={true}
                            />
                            {formErrors.job_type && <div className="form-label text-danger m-1">{formErrors.job_type}</div>}
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                          <div className="mb-3">
                            <label className="form-label">Select Languages <span className="text-danger">*</span></label>
                            
                            <Select
                              className="select"
                              options={langOptions}
                              value={langOptions.find(option => option.value == formData.languages)}
                              onChange={(selected) => setFormData({...formData, languages: selected.value})}
                              placeholder="Select"
                              isClearable={true}
                              isSearchable={true}
                            />
                            {formErrors.languages && <div className="form-label text-danger m-1">{formErrors.languages}</div>}
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                          <div className="mb-3">
                            <label className="form-label">Select Visit Type <span className="text-danger">*</span></label>
                            
                            <Select
                              className="select"
                              name="visit_type"
                              options={visitType}
                              value={visitType.find(option => option.value == formData.visit_type)}
                              onChange={(selected) => setFormData({...formData, visit_type: selected.value})}
                              placeholder="Select"
                              isClearable={true}
                              isSearchable={true}
                            />
                            {formErrors.visit_type && <div className="form-label text-danger m-1">{formErrors.visit_type}</div>}
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                          <div className="mb-3">
                            <label className="form-label">Contact Person <span className="text-danger">*</span></label>
                            <input type="text" name="contact_person" value={formData.contact_person} onChange={handleInputChange} className="form-control" />
                            {formErrors.contact_person && <div className="form-label text-danger m-1">{formErrors.contact_person}</div>}
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                          <div className="mb-3">
                            <label className="form-label">Address 1<span className="text-danger">*</span></label>
                            <input type="text" name="address1" value={formData.address1} onChange={handleInputChange} className="form-control" />
                            {formErrors.address1 && <div className="form-label text-danger m-1">{formErrors.address1}</div>}
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                          <div className="mb-3">
                            <label className="form-label">Address 2</label>
                            <input type="text" name="address2" value={formData.address2} onChange={handleInputChange} className="form-control" />
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                          <div className="mb-3">
                            <label className="form-label">City <span className="text-danger">*</span></label>
                            <input type="text" name="city" value={formData.city} onChange={handleInputChange} className="form-control" />
                            {formErrors.city && <div className="form-label text-danger m-1">{formErrors.city}</div>}
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                          <div className="mb-3">
                            <label className="form-label">Select State <span className="text-danger">*</span></label>
                            
                            <Select
                              className="select"
                              name="state"
                              options={stateOptions}
                              value={stateOptions.find(option => option.value == formData.state)}
                              onChange={(selected) => setFormData({...formData, state: selected.value})}
                              placeholder="Select"
                              isClearable={true}
                              isSearchable={true}
                            />
                            {formErrors.state && <div className="form-label text-danger m-1">{formErrors.state}</div>}
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                          <div className="mb-3">
                            <label className="form-label">Select Country <span className="text-danger">*</span></label>
                            
                            <Select
                              className="select"
                              name="country"
                              options={cntryOptions}
                              value={cntryOptions.find(option => option.value == formData.country)}
                              onChange={(selected) => setFormData({...formData, country: selected.value})}
                              placeholder="Select"
                              isClearable={true}
                              isSearchable={true}
                            />
                            {formErrors.country && <div className="form-label text-danger m-1">{formErrors.country}</div>}
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                          <div className="mb-3">
                            <label className="form-label">Zipcode <span className="text-danger">*</span></label>
                            <input type="text" name="zipcode" value={formData.zipcode} onChange={handleInputChange} className="form-control" />
                            {formErrors.zipcode && <div className="form-label text-danger m-1">{formErrors.zipcode}</div>}
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                          <div className="mb-3">
                            <label className="form-label">Contact <span className="text-danger">*</span></label>
                            <input type="text" name="contact_phone" value={formData.contact_phone} onChange={handleInputChange} className="form-control" />
                            {formErrors.contact_phone && <div className="form-label text-danger m-1">{formErrors.contact_phone}</div>}
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                          <div className="mb-3">
                            <label className="form-label">Pay <span className="text-danger">*</span></label>
                            <input type="text" name="pay" value={formData.pay} onChange={handleInputChange} className="form-control" />
                            {formErrors.pay && <div className="form-label text-danger m-1">{formErrors.pay}</div>}
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                          <div className="mb-3">
                            <label className="form-label">CPR/BLS: </label>
                            
                            <Select
                              className="select"
                              name="cpr_bls"
                              options={boolOption}
                              value={boolOption.find(option => option.value === formData.cpr_bls)}
                              onChange={(selected) => setFormData({...formData, cpr_bls: selected.value})}
                              placeholder="Select"
                              isClearable={true}
                              isSearchable={true}
                            />
                            
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-6">
                          <div className="mb-3">
                            <label className="form-label">License:</label>
                            
                            <Select
                              className="select"
                              name="license"
                              options={boolOption}
                              value={boolOption.find(option => option.value === formData.license)}
                              onChange={(selected) => setFormData({...formData, license: selected.value})}
                              placeholder="Select"
                              isClearable={true}
                              isSearchable={true}
                            />
                            
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="card-footer">
                  <div className="d-flex align-items-center flex-wrap rpw-gap-2 justify-content-between">
                    <Link
                      to="#"
                      className="btn btn-md btn-dark inline-flex align-items-center rounded-pill"
                    >
                      <i className="isax isax-arrow-left-2 me-1" />
                      Back
                    </Link>
                    <input type='submit' value='Add Job Work Hours' className="btn btn-md btn-primary-gradient next_btns inline-flex align-items-center rounded-pill" />
                    {/* <Link
                      to="#"
                      className="btn btn-md btn-primary-gradient next_btns inline-flex align-items-center rounded-pill"
                      onClick={handleNext}
                    >
                      Add Job Work Hours
                      <i className="isax isax-arrow-right-3 ms-1" />
                    </Link> */}
                  </div>
                </div>
              </div>
            </fieldset>
          </form>
          )}
            {currentStep === 2 && (
            <fieldset style={{display:'block'}}>
              <div className="card booking-card mb-0">
                <div className="card-header">
                <h3>Job Work Hours</h3>
                </div>
                <div className="card-body booking-body">
                  <div className="card mb-0">
                    <div className="card-body pb-1">
                      <div className="row">
                        <div className="col-lg-5">
                          <div className="card">
                            <div className="card-body p-2 pt-3">
                            <div style={wrapperStyle}>
                            <Calendar fullscreen={false} onPanelChange={onPanelChange} />
                            </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-lg-7">
                          <div className="card booking-wizard-slots">
                            <div className="card-body">
                              <div className="book-title">
                                <h6 className="fs-14 mb-2">Morning</h6>
                              </div>
                              <div className="token-slot mt-2 mb-2">
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                      defaultChecked
                                    />
                                    <span className="visit-rsn">09:45</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">-</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">10:45</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">10:45</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">10:45</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">-</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">09:45</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">-</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">10:45</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">10:45</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">10:45</span>
                                  </label>
                                </div>
                              </div>
                              <div className="book-title">
                                <h6 className="fs-14 mb-2">Afternoon</h6>
                              </div>
                              <div className="token-slot mt-2 mb-2">
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                      defaultChecked
                                    />
                                    <span className="visit-rsn">09:45</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">-</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">10:45</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">10:45</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">10:45</span>
                                  </label>
                                </div>
                              </div>
                              <div className="book-title">
                                <h6 className="fs-14 mb-2">Evening</h6>
                              </div>
                              <div className="token-slot mt-2 mb-2">
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                      defaultChecked
                                    />
                                    <span className="visit-rsn">09:45</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">-</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">10:45</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">10:45</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">10:45</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">-</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">09:45</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">-</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">10:45</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">10:45</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">10:45</span>
                                  </label>
                                </div>
                                <div className="form-check-inline visits me-1">
                                  <label className="visit-btns">
                                    <input
                                      type="checkbox"
                                      className="form-check-input"
                                      name="appintment"
                                    />
                                    <span className="visit-rsn">-</span>
                                  </label>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="card-footer">
                  <div className="d-flex align-items-center flex-wrap rpw-gap-2 justify-content-between">
                    <Link
                      to="#"
                      className="btn btn-md btn-dark prev_btns inline-flex align-items-center rounded-pill"
                      onClick={handlePrev}
                    >
                      <i className="isax isax-arrow-left-2 me-1" />
                      Back
                    </Link>
                    <Link
                      to="#"
                      className="btn btn-md btn-primary-gradient next_btns inline-flex align-items-center rounded-pill"
                      onClick={handleNext}
                    >
                      Submit
                      <i className="isax isax-arrow-right-3 ms-1" />
                    </Link>
                  </div>
                </div>
              </div>
            </fieldset>
        )}
            {currentStep === 3 && (
            <fieldset style={{display:'block'}}>
              <div className="card booking-card">
                <div className="card-body pb-1">
                  <div className="login-content-info">
                    <div className="container">
                      {/* Login Phone */}
                      <div className="row justify-content-center">
                        <div className="col-lg-6 col-md-8">
                          <div className="account-content">
                            <div className="account-info">
                              <div className="login-verify-img">
                                <i className="isax isax-tick-circle" />
                              </div>
                              <div className="login-title">
                                <h3>Success</h3>
                                <p>Job Registration has been Successfully</p>
                              </div>
                              <form>
                                <div className="mb-3">
                                  <Link
                                    className="btn btn-primary-gradient w-100"
                                    to='/site-login'
                                  >
                                    Sign In
                                  </Link>
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>
                      </div>
                    {/* /Login Phone */}
                  </div>
                </div>
                </div>
              </div>
              <div>
                <Link to="#" className="" onClick={()=>setCurrentStep(1)}>
                  <i className="isax isax-arrow-left-2 me-1" />
                  Back to first
                </Link>
              </div>
            </fieldset>
        )}
          </div>
          <div className="text-center">
            <p className="mb-0">
              Copyright © {new Date().getFullYear()}. All Rights Reserved, Doccure
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

  )
}

export default JobRegistration