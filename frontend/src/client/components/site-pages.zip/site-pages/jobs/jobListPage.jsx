import React, { useState, useEffect } from "react";
import axios from "axios";
import { API_BASE_URL,AUTH_TOKEN, disciplineOptions, specialtyOptions, visitType, jobTypeOptions, paginationDefaultCount, workSettingOptions} from "../config";
import { convertToUS } from "../utils";
import Pagination from '../pagination';
import { FaTimesCircle, FaEye, FaSearch, FaHourglassHalf, FaPlusCircle } from "react-icons/fa";
import { Link, useHistory } from "react-router-dom";
import SiteHeader from "../home/header.jsx";
import SiteFooter from "../home/footer.jsx";
import { doctor_thumb_01, doctor_thumb_02, doctor_thumb_03, doctor_thumb_05, doctor_thumb_07, doctor_thumb_08, doctor_thumb_09, logo } from "../../imagepath.jsx";
import ImageWithBasePath from "../../../../core/img/imagewithbasebath.jsx";

const JobListPage = (props) => {
    const [job, setjob] = useState([]);
    const [error, setError] = useState(null);
    const [success, setSuccess] = useState(null);

    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemPerPage] = useState(paginationDefaultCount);
    
    const [sortOrder, setSortOrder] = useState('asc');
    const [sortField, setSortField] = useState('start_date'); 
    
    const facID = atob(localStorage.getItem('userID')) || "";
    console.log("FacID",facID)
    const history = useHistory();
    const handleAdd = () => history.push('/facility/addjob')
    const fetchjob = async () => {
        try {
            const response = await axios.get(`${API_BASE_URL}/jobs/GetJobs/?method=all&FacID=${facID}`,{
                headers: { 
                    "Content-Type": "application/json",
                    'Authorization': AUTH_TOKEN
                 },
            });
            setjob(response.data.data);
        } catch (err) {
            setError(err.response?.data?.Result || "An error occurred");
        }
    };

    const deletejob = async (id) => {
        try {
            await axios.delete(`${API_BASE_URL}/jobs/DeleteJobs/${id}/`,{
                headers: { 
                    "Content-Type": "application/json",
                    'Authorization': AUTH_TOKEN
                },
            });
            setjob(job.filter((job) => job.id !== id));
            setSuccess("Job deleted successfully")
        } catch (err) {
            setError(err.response?.data?.Result || "Error deleting job");
        }
    };
    const viewJob = async (id) => {
      localStorage.setItem("currentJobID",btoa(id))
      history.push("/facility/viewjob") 
    }

    const searchJob = async (id) => {
      localStorage.setItem('searchJobID',btoa(id))
      localStorage.setItem('setJobSearch',true)
      history.push('/facility/search')
  }

    useEffect(() => {
        fetchjob();
    },[facID]);

    const handleSort = (field) => {
        let newSortOrder = 'asc';
        if (sortField === field && sortOrder === 'asc') {
          newSortOrder = 'desc';
        }
        setSortOrder(newSortOrder);
        setSortField(field);
    
        const sortedData = [...job].sort((a, b) => {
          if (field === 'status' || field === 'contact_person' || field === 'job_title' ) {
            const nameA = a[field].toLowerCase();
            const nameB = b[field].toLowerCase();
            if (nameA < nameB) return newSortOrder === 'asc' ? -1 : 1;
            if (nameA > nameB) return newSortOrder === 'asc' ? 1 : -1;
            return 0;
          } else if (field === 'start_date' || field === 'end_date') {
            const dateA = new Date(a[field]);
            const dateB = new Date(b[field]);
            return newSortOrder === 'asc' ? dateA - dateB : dateB - dateA;
          }
          return 0;
        });
    
        setjob(sortedData);
      };

    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentJobs = job.slice(indexOfFirstItem, indexOfLastItem);

  return (
    <div>
      <SiteHeader {...props} />
      <>
        {/* Breadcrumb */}
        <div className="breadcrumb-bar">
          <div className="container">
            <div className="row align-items-center inner-banner">
              <div className="col-md-12 col-12 text-center">
                <nav aria-label="breadcrumb" className="page-breadcrumb">
                  <ol className="breadcrumb">
                    <li className="breadcrumb-item">
                      <a href="/home">
                        <i className="isax isax-home-15" />
                      </a>
                    </li>
                    <li className="breadcrumb-item" aria-current="page">
                      Jobs
                    </li>
                    <li className="breadcrumb-item active">Job</li>
                  </ol>
                  <h2 className="breadcrumb-title">Job</h2>
                </nav>
              </div>
            </div>
          </div>
          <div className="breadcrumb-bg">
          <ImageWithBasePath
              src="assets/img/bg/breadcrumb-bg-01.png"
              alt="img"
              className="breadcrumb-bg-01"
            />
            <ImageWithBasePath
              src="assets/img/bg/breadcrumb-bg-02.png"
              alt="img"
              className="breadcrumb-bg-02"
            />
            <ImageWithBasePath
              src="assets/img/bg/breadcrumb-icon.png"
              alt="img"
              className="breadcrumb-bg-03"
            />
            <ImageWithBasePath
              src="assets/img/bg/breadcrumb-icon.png"
              alt="img"
              className="breadcrumb-bg-04"
            />
          </div>
        </div>
        {/* /Breadcrumb */}
      </>

      {/* Page Content */}
      <div className="content doctor-content">
        <div className="container">
          <div className="row">
            {/* Invoices */}
            <div className="col-lg-12 col-xl-12">
              <div className="dashboard-header">
                <h3>Jobs <FaPlusCircle title="Add job" className="text-success m-1" onClick={handleAdd}/></h3>
              </div>
              <div className="search-header">
                <div className="search-field">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search"
                  />
                  <span className="search-icon">
                    <i className="fa-solid fa-magnifying-glass" />
                  </span>
                </div>
              </div>
              {error && <p className="text-danger m-2">{error}</p>}
              {success && <p className="text-success m-2">{success}</p>}
              <div className="tab-content appointment-tab-content">
                <div
                  className="tab-pane fade show active"
                  id="pills-upcoming"
                  role="tabpanel"
                  aria-labelledby="pills-upcoming-tab"
                >
                              
                {
                  currentJobs.length === 0 ? (
                      <tr><td colSpan="10">No jobRequest found</td></tr>
                  ) : (
                  currentJobs.map((jobs) => (
                  <div className="appointment-wrap">
                    <ul className="col-1 offset-11 mb-2">
                      <li>
                        <div className="patinet-information" style={{minWidth:"0px"}}>
                          <div className="patient-info">
                            <span className="btn btn-block w-100 btn-outline-success active">
                              <i className="fa-solid fa-circle" />&nbsp;
                              {jobs.status}{" "}
                            </span>
                          </div>
                        </div>
                      </li>
                    </ul>
                    <ul>
                      <li>
                        <div className="patinet-information" style={{minWidth:"0px"}}>
                          <div className="patient-info">
                            <p>Discipline - &nbsp;
                                <Link to="#">
                                  {disciplineOptions.map(disp => {
                                    if (disp.value === jobs.discipline) {
                                      return disp.label;
                                    }
                                  return null;
                                  })}
                                </Link>
                            </p>
                            
                            <p>Visit Type - &nbsp;
                                <Link to="#">
                                  {visitType.map(visit => {
                                      if (visit.value === jobs.visit_type) {
                                          return visit.label
                                      }
                                      return null;
                                  })}
                                </Link>
                            </p>
                          </div>
                        </div>
                      </li>
                      <li>
                        <div className="patinet-information" style={{minWidth:"0px"}}>
                          <div className="patient-info">
                            <p>Job  Title</p>
                            <Link to="#">{jobs.job_title}</Link>
                          </div>
                        </div>
                      </li>
                      <li>
                        <div className="patinet-information" style={{minWidth:"0px"}}>
                          <div className="patient-info">
                            <p>Start Date</p>
                            <Link to="#">{convertToUS(jobs.start_date,"Date")}</Link>
                          </div>
                        </div>
                      </li>
                      <li>
                        <div className="patinet-information" style={{minWidth:"0px"}}>
                          <div className="patient-info">
                            <p>End Date</p>
                            <Link to="#">{convertToUS(jobs.end_date,"Date")}</Link>
                          </div>
                        </div>
                      </li>
                      <ul>
                        <li>
                          <div className="patinet-information" style={{minWidth:"0px"}}>
                            <div className="patient-info">
                              <p>Actions</p>
                              <FaEye title="View job" className="text-primary" style={{fontSize:"19px"}} onClick={() => viewJob(jobs.id)}/>
                              <FaTimesCircle title="Delete job" className="text-danger m-2" style={{fontSize:"17px"}} onClick={() => deletejob(jobs.id)}/>
                              {(jobs.status === "Inactive") 
                              ?
                              <FaHourglassHalf title="Add Work Hours" className="text-secondary" style={{fontSize:"17px"}}/>
                              :
                              <FaSearch title="Search professional" className="text-secondary" style={{fontSize:"17px"}} onClick={() => searchJob(jobs.id)}/>
                              } 
                            </div>
                          </div>  
                        </li>
                      </ul>
                    </ul>
                    <hr/>
                    <ul className="col-7">
                    <li>
                      <div className="patinet-information" style={{minWidth:"0px"}}>
                        <div className="patient-info">
                          <p>
                            <i className="fa-solid fa-clock" />&nbsp;{convertToUS(jobs.created,"DateTime")} &nbsp;by&nbsp; {jobs.created_by}
                          </p>
                        </div>
                      </div>
                    </li>
                    <li>
                      <div className="patinet-information" style={{minWidth:"0px"}}>
                        <div className="patient-info">
                          <p>Work Setting - &nbsp;
                            <Link to="#">
                              {workSettingOptions.map(wrk => {
                                if (wrk.value === jobs.work_setting) {
                                    return wrk.label;
                                }
                                return null;
                              })}
                            </Link>
                          </p>
                        </div>
                      </div>
                    </li> 
                    <li>
                      <div className="patinet-information" style={{minWidth:"0px"}}>
                        <div className="patient-info">
                          <p>Specialty - &nbsp;
                            <Link to="#">
                              {specialtyOptions.map(spl => {
                                if (spl.value === jobs.speciality) {
                                    return spl.label;
                                }
                                return null;
                              })}
                            </Link>
                          </p>
                        </div>
                      </div>
                    </li>        
                    </ul>
                  </div>
                    ))
                  )
                }
                </div>
              </div>
              {/* Pagination */}
              {(job.length === 0) ? 
                null 
              :
                <Pagination setCurrentPage={setCurrentPage} itemsPerPage={itemsPerPage} currentPage={currentPage} data={job}/>
              }
              {/* /Pagination */}
            </div>
            {/* /Invoices */}
          </div>
        </div>
      </div>
      {/* /Page Content */}
      {/*View Invoice */}
      <div className="modal fade custom-modals" id="invoice_view">
        <div
          className="modal-dialog modal-dialog-centered modal-lg"
          role="document"
        >
          <div className="modal-content">
            <div className="modal-header">
              <h3 className="modal-title">View Invoice</h3>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              >
                <i className="fa-solid fa-xmark" />
              </button>
            </div>
            <div className="modal-body pb-0">
              <div className="prescribe-download">
                <h5>21 Mar 2025</h5>
                <ul>
                  <li>
                    <Link to="#" className="print-link">
                      <i className="isax isax-printer5" />
                    </Link>
                  </li>
                  <li>
                    <Link to="#" className="btn btn-primary prime-btn">
                      Download
                    </Link>
                  </li>
                </ul>
              </div>
              <div className="view-prescribe invoice-content">
                <div className="invoice-item">
                  <div className="row">
                    <div className="col-md-6">
                      <div className="invoice-logo">
                        <img src={logo} alt="logo" />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <p className="invoice-details">
                        <strong>Invoice No : </strong> #INV005
                        <br />
                        <strong>Issued:</strong> 21 Mar 2025
                      </p>
                    </div>
                  </div>
                </div>
                {/* Invoice Item */}
                <div className="invoice-item">
                  <div className="row">
                    <div className="col-md-4">
                      <div className="invoice-info">
                        <h6 className="customer-text">Billing From</h6>
                        <p className="invoice-details invoice-details-two">
                          Edalin Hendry <br />
                          806 Twin Willow Lane, <br />
                          Newyork, USA <br />
                        </p>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="invoice-info">
                        <h6 className="customer-text">Billing To</h6>
                        <p className="invoice-details invoice-details-two">
                          Richard Wilson <br />
                          299 Star Trek Drive
                          <br />
                          Florida, 32405, USA
                          <br />
                        </p>
                      </div>
                    </div>
                    <div className="col-md-4">
                      <div className="invoice-info invoice-info2">
                        <h6 className="customer-text">Payment Method</h6>
                        <p className="invoice-details">
                          Debit Card <br />
                          XXXXXXXXXXXX-2541
                          <br />
                          HDFC Bank
                          <br />
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                {/* /Invoice Item */}
                {/* Invoice Item */}
                <div className="invoice-item invoice-table-wrap">
                  <div className="row">
                    <div className="col-md-12">
                      <h6>Invoice Details</h6>
                      <div className="table-responsive">
                        <table className="invoice-table table table-bordered">
                          <thead>
                            <tr>
                              <th>Description</th>
                              <th>Quatity</th>
                              <th>VAT</th>
                              <th>Total</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>General Consultation</td>
                              <td>1</td>
                              <td>$0</td>
                              <td>$150</td>
                            </tr>
                            <tr>
                              <td>Video Call</td>
                              <td>1</td>
                              <td>$0</td>
                              <td>$100</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div className="col-md-6 col-xl-4 ms-auto">
                      <div className="table-responsive">
                        <table className="invoice-table-two table">
                          <tbody>
                            <tr>
                              <th>Subtotal:</th>
                              <td>
                                <span>$350</span>
                              </td>
                            </tr>
                            <tr>
                              <th>Discount:</th>
                              <td>
                                <span>-10%</span>
                              </td>
                            </tr>
                            <tr>
                              <th>Total Amount:</th>
                              <td>
                                <span>$315</span>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
                {/* /Invoice Item */}
                {/* Invoice Information */}
                <div className="other-info mb-0">
                  <h4>Other information</h4>
                  <p className="text-muted mb-0">
                    An account of the present illness, which includes the
                    circumstances surrounding the onset of recent health changes and
                    the chronology of subsequent events that have led the patient to
                    seek medicine
                  </p>
                </div>
                {/* /Invoice Information */}
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* /View Invoice */}
      <SiteFooter />

    </div>
  );
};

export default JobListPage;
