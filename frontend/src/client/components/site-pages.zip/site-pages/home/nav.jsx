import React, { useState, useEffect } from "react";
import { Link, NavLink } from "react-router-dom";
import ImageWithBasePath from "../../../../core/img/imagewithbasebath";
import { useLocation } from "react-router-dom";
import c from "config";

const NavLinks = () => {
  const [menu, setMenu] = useState(false);
  const [isSideMenu, setSideMenu] = useState("");
  const [isSideDoctor, setSideDoctor] = useState("");
  const [isSideMenuone, setSideMenuone] = useState("");
  const [isSideMenutwo, setSideMenutwo] = useState("");
  const [isSideMenuthree, setSideMenuthree] = useState("");
  const [isSideMenufour, setSideMenufour] = useState("");
  const [sideMenufive, setSideMenufive] = useState("");
  const [isSideSearch, setSideSearch] = useState("");
  const [isSidebooking, setSideBooking] = useState("");

  const [showHeader, setShowHeader]                 = useState("block");
  const [facilityHeader, setFacilityHeader]         = useState("block");
  const [professionalHeader, setProfessionalHeader] = useState("block");

  const userType = atob(localStorage.getItem('group'));
  console.log('userType', userType);

  // Rest of your code that uses pathnames
  const Location = useLocation()
  const pathnames = Location.pathname;
  const url = pathnames.split("/").slice(0, -1).join("/");

  console.log("url",url)
  console.log("pathnames",pathnames)
  
  const onhandleCloseMenu = () => {
    var root = document.getElementsByTagName("html")[0];
    root.classList.remove("menu-opened");
  };
  const toggleSidebarbooking = (value) => {
    setSideBooking(value);
  };
  const toggleSidebarDoctor = (value) => {
    setSideDoctor(value);
  };
  const toggleSidebarthree = (value) => {
    setSideMenuthree(value);
  };
  const toggleSidebar = (value) => {
    setSideMenu(value);
  };
  const toggleSidebarfour = (value) => {
    setSideMenufour(value);
  };
  const toggleSidebarfive = (value) => {
    setSideMenufive(value);
  };
  const toggleSidebarone = (value) => {
    setSideMenuone(value);
  };
  const toggleSidebartwo = (value) => {
    setSideMenutwo(value);
  };
  const toggleSidebarsearch = (value) => {
    setSideSearch(value);
  };

  const showProfessionalHeader = () => {
    url.includes('/professional') ? pathnames.includes('/professional/register') ? setProfessionalHeader("none"):null:null
  }

  const showFacilityHeader = () => {
    url.includes('/facility') ? pathnames.includes('/facility/register') ? setFacilityHeader("none"): setFacilityHeader("block") : setFacilityHeader("none")
  }

  const showUserHeader = () => {
    url ? (pathnames.includes('/professional/register') || pathnames.includes('/facility/register') )  ? setShowHeader("none") : setShowHeader("block") : setShowHeader("none")
  }

  useEffect(()=>{
    showProfessionalHeader();
    showFacilityHeader();
    showUserHeader();
  },[url])

  return (
    <>
      {userType === "Administrator" ?
        <>
          <li>
            <NavLink
              to="/site-user/dashboard"
              onClick={() => setMenu(!menu)}
              className={`${menu === true ? "submenu " : ""}`}
            >
              Home
            </NavLink>
          </li>

          <li>
            <NavLink
              to="/site-user/professional"
              onClick={() => setMenu(!menu)}
              className={`${menu === true ? "submenu " : ""}`}
            >
              Professionals
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/site-user/facility"
              onClick={() => setMenu(!menu)}
              className={`${menu === true ? "submenu " : ""}`}
            >
              Facilities
            </NavLink>
          </li>

          <li>
            <NavLink
              to="/site-user/jobs"
              onClick={() => setMenu(!menu)}
              className={`${menu === true ? "submenu " : ""}`}
            >
              Jobs
            </NavLink>
          </li>

          <li>
            <NavLink
              to="#"
              onClick={() => setMenu(!menu)}
              className={`${menu === true ? "submenu " : ""}`}
              style={{color:"#2e3842"}}
            >
              Contracts
            </NavLink>
          </li>   

          <li>
            <NavLink
              to="#"
              onClick={() => setMenu(!menu)}
              className={`${menu === true ? "submenu " : ""}`}
              style={{color:"#2e3842"}}
            >
              Shifts
            </NavLink>
          </li>                    

        </>
        :
        <>
        <li
          className={`has-submenu megamenu  ${
            pathnames.includes("index")
              ? "active"
              : "" || pathnames.includes("home")
              ? "active"
              : ""
          }`}
        >
          {!url ?
            <NavLink
              to="/site-login"
              onClick={() => setMenu(!menu)}
              className={`${menu === true ? "submenu " : ""}`}
            >
              Home
            </NavLink>
          :
            <NavLink
              to={url.includes("/professional") ? "/professional/dashboard" : "/facility/dashboard"}
              onClick={() => setMenu(!menu)}
              className={`${menu === true ? "submenu " : ""}`}
            >
              Home
            </NavLink>
          }
          <ul
            className={`${
              menu === true
                ? "submenu mega-submenu d-block"
                : "submenu mega-submenu"
            }`}
          >
          </ul>
        </li>
      
      {/* <li className={`has-submenu`} style={{display:`${!url ? "block": "none"}`}}>
        <NavLink
          to="#"
          className={isSideMenu == "doctors" ? "subdrop " : ""}
          onClick={() =>
            toggleSidebar(isSideMenu == "doctors" ? "submenu" : "doctors")
          }
          onMouseEnter={() =>
            toggleSidebar(isSideMenu == "doctors" ? "submenu" : "doctors")
          }
        >
          Site Pages <i className="fas fa-chevron-down" />
        </NavLink>
        {isSideMenu == "doctors" ? (
          <ul
            className={`${
              isSideMenu == "doctors" ? "submenu d-block" : "submenu"
            }`}
          >
            <li
              className={
                pathnames.includes("doctor-dashboard") ||
                pathnames.includes("doctor-specialities")
                  ? "active"
                  : ""
              }
            >
              <NavLink
                to="/facility/register"
                onClick={() => onhandleCloseMenu()}
              >
                Facility Register
              </NavLink>
            </li>
            <li
              className={
                pathnames.includes("appointments") ||
                pathnames.includes("doctor-request")
                  ? "active"
                  : ""
              }
            >
              <NavLink
                to="/professional/register"
                onClick={() => onhandleCloseMenu()}
              >
                Professional Register
              </NavLink>
            </li>
            <li className={pathnames.includes("my-patients") ? "active" : ""}>
              <NavLink
                to="/facility/dashboard"
                onClick={() => onhandleCloseMenu()}
              >
                Facility Dashboard
              </NavLink>
            </li>
            <li
              className={pathnames.includes("patient-profile") ? "active" : ""}
            >
              <NavLink
                to="/professional/dashboard"
                onClick={() => onhandleCloseMenu()}
              >
                Professional Dashboard
              </NavLink>
            </li>
            <li className={pathnames.includes("chat-doctor") ? "active" : ""}>
              <NavLink
                to="/facility/myprofile"
                onClick={() => onhandleCloseMenu()}
              >
                Facility Profile
              </NavLink>
            </li>
            <li className={pathnames.includes("invoices") ? "active" : ""}>
              <NavLink to="/professional/myprofile" onClick={() => onhandleCloseMenu()}>
              Professional Profile
              </NavLink>
            </li>
            <li className={pathnames.includes("invoices") ? "active" : ""}>
              <NavLink to="/facility/search" onClick={() => onhandleCloseMenu()}>
              Search
              </NavLink>
            </li>
            <li className={pathnames.includes("invoices") ? "active" : ""}>
              <NavLink to="/facility/jobs" onClick={() => onhandleCloseMenu()}>
              Jobs
              </NavLink>
            </li>
            <li className={pathnames.includes("invoices") ? "active" : ""}>
              <NavLink to="/facility/addjob" onClick={() => onhandleCloseMenu()}>
              Add Job
              </NavLink>
            </li>
            <li className={pathnames.includes("invoices") ? "active" : ""}>
              <NavLink to="/facility/viewjob" onClick={() => onhandleCloseMenu()}>
              View Job
              </NavLink>
            </li>
            
          </ul>
        ) : (
          ""
        )}
      </li> */}

      <li className= "has-submenu" style={{display: facilityHeader}}>
        <NavLink
          to= "/facility/jobs"
          className= "subdrop"
          // onMouseEnter={() =>
          //   toggleSidebar(isSideMenu == "patients" ? "submenu" : "patients")
          // }
        >
          Jobs
        </NavLink>
      </li>

      <li className= "has-submenu" style={{display:`${url ? (pathnames.includes('/facility/register') || pathnames.includes('/professional/register')) ?  "block":"none" :"block"}`}}>
        <NavLink
          to= "/about-us"
          className= "subdrop"
          // onMouseEnter={() =>
          //   toggleSidebar(isSideMenu == "patients" ? "submenu" : "patients")
          // }
        >
          About Us
        </NavLink>
      </li>

      <li className= "has-submenu" style={{display:`${url ? (pathnames.includes('/facility/register') || pathnames.includes('/professional/register')) ?  "block":"none" :"block"}`}}>
        <NavLink
          to= "/contact-us"
          className= "subdrop"
          // onMouseEnter={() =>
          //   toggleSidebar(isSideMenu == "patients" ? "submenu" : "patients")
          // }
        >
          Contact
        </NavLink>
      </li>

      <li className= "has-submenu" style={{display:showHeader}}>
        <NavLink
          to= {url.includes("/professional") ? "/professional/job-requests" : "/facility/job-requests"}
          className= "subdrop"
          // onMouseEnter={() =>
          //   toggleSidebar(isSideMenu == "patients" ? "submenu" : "patients")
          // }
        >
          Job Request
        </NavLink>
      </li>

      <li className= "has-submenu" style={{display:showHeader}}>
        <NavLink
          to= {url.includes("/professional") ? "/professional/contracts" : "/facility/contracts"}
          className= "subdrop"
          // onMouseEnter={() =>
          //   toggleSidebar(isSideMenu == "patients" ? "submenu" : "patients")
          // }
        >
          Contracts
        </NavLink>
      </li>

      <li className= "has-submenu" style={{display:showHeader}}>
        <NavLink
          to= "#"
          className= "subdrop"
          style={{color:"#2e3842"}}
          // onMouseEnter={() =>
          //   toggleSidebar(isSideMenu == "patients" ? "submenu" : "patients")
          // }
        >
          Billing
        </NavLink>
      </li>

      <li className= "has-submenu" style={{display:showHeader}}>
        <NavLink
          to= {url.includes("/professional") ? "/professional/myprofile" : "/facility/myprofile"}
          className= "subdrop"
          // onMouseEnter={() =>
          //   toggleSidebar(isSideMenu == "patients" ? "submenu" : "patients")
          // }
        >
          My profile
        </NavLink>
      </li>

      <li className= "has-submenu" style={{display:showHeader}}>
        <NavLink
          to= "#"
          className= "subdrop"
          style={{color:"#2e3842"}}
          // onMouseEnter={() =>
          //   toggleSidebar(isSideMenu == "patients" ? "submenu" : "patients")
          // }
        >
          Shifts
        </NavLink>
      </li>
    </>
    }
    </>
  );
};

export default NavLinks;
