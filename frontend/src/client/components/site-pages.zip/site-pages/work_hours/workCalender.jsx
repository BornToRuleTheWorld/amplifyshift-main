import React, { useState, useEffect } from "react";
import axios from "axios";
import {AUTH_TOKEN, API_BASE_URL} from '../config';
import {convertTo12HourFormat, convertToUS} from "../utils"
import { Calendar as BigCalendar, momentLocalizer } from 'react-big-calendar';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import moment from 'moment';

const WorkHoursCalender = ({ID, Role}) => {
    
    const [error, setError] = useState(null)
    const [success, setSuccess] = useState(null)
    const [facData, setFacData] = useState([]);
    const [slotData, setSlotData] = useState([]);
    const [fetchSlot, setFetchSlot] = useState(false);
    const [calendarData, setCalendarData] = useState([]);
    const [slotID, setSlotID] = useState({slot_ids: []});
    const [showSlots, setShowSlots] = useState({
      date:"",
      show:false,
      slots:[]
    });
    const localizer = momentLocalizer(moment);

    var getUrl = ""
    
    if (Role === "Job"){
        getUrl = `${API_BASE_URL}/jobs/GetJobWorkHours/?JobID=${ID}`
    }else{
        getUrl = `${API_BASE_URL}/contract/GetContractHours/?ConID=${ID}`
    }

    useEffect(() => {
      axios
        .get(getUrl, {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': AUTH_TOKEN,
          }
        })
        .then((response) => {
          setFacData(response.data.data);
          const extractedSlotIds = response.data.data ? response.data.data.map(slot => slot.slot) : [];
          setSlotID({ slot_ids: extractedSlotIds });
          setFetchSlot(true)
        })
        .catch((err) => {
          console.error('Error fetching facility data:', err);
          setError(err.response.data.Result)
        });
    }, [ID, AUTH_TOKEN]);
  
    useEffect(() => {
      if (fetchSlot) {
        axios
          .post(`${API_BASE_URL}/GetSlot/`, slotID, {
            headers: {
              'Content-Type': 'application/json',
              'Authorization': AUTH_TOKEN
            }
          })
          .then((response) => {
            setSlotData(response.data.data);
          })
          .catch((err) => {
            console.error('Error fetching slot data:', err);
            setError(err.response.data.Result)
          });
      }
    }, [fetchSlot]);
  
    useEffect(() => {
      const events = facData.map((slotInfo) => {
        const slotDetails = slotData.find(slot => slot.id === slotInfo.slot);
        if (slotDetails) {
          return {
            title: slotInfo.status,
            start: new Date(slotInfo.date + ' ' + convertTo12HourFormat(slotDetails.start_hr)),
            end: new Date(slotInfo.date + ' ' + convertTo12HourFormat(slotDetails.end_hr)),
            slot : `${convertTo12HourFormat(slotDetails.start_hr)} - ${convertTo12HourFormat(slotDetails.end_hr)}`,
            allDay: false,
            id: slotInfo.slot
          };
        }
        return null;
      })
      setCalendarData(events);
    }, [facData, slotData]);


    const handleSelectSlot = ({ start }) => {
      const selectedDate = convertToUS(start,"Date");
    
      const matchingSlots = calendarData.filter(event => {
        const eventDate = convertToUS(event.start,"Date");
        return eventDate === selectedDate;
      });
    
      const slotsWithDetails = matchingSlots.map((event) => {
        const slotDetails = slotData.find(slot => slot.id === event.id);
        if (slotDetails) {
          const formattedSlot = {
            ...event,
            slot: `${convertTo12HourFormat(slotDetails.start_hr)} - ${convertTo12HourFormat(slotDetails.end_hr)}`
          };
          return formattedSlot;
        }
        return null;
      }).filter(event => event !== null);
    
      if (slotsWithDetails.length > 0) {
        setShowSlots({
          ...showSlots,
          show: true,
          date: selectedDate,
          slots: slotsWithDetails
        });
      } else {
        setShowSlots({
          ...showSlots,
          show: false,
          date: selectedDate,
          slots: []
        });
      }
    };
  
    if (!facData || !slotData) {
      return <div>Loading...</div>;
    }
  
    return (
        <div className="row">
            <div className="tab-content appointment-tab-content">
                <div
                    className="tab-pane fade show active"
                    id="pills-upcoming"
                    role="tabpanel"
                    aria-labelledby="pills-upcoming-tab"
                >
                <div className="row">
                <div className="col-9">
                    <BigCalendar
                      localizer={localizer}
                      events={calendarData}
                      startAccessor="start"
                      endAccessor="end"
                      style={{ height:800,border:"1px solid grey", padding:"10px",borderRadius:"7px"}}
                      views={['month','week','day']}
                      selectable={true}
                      onSelectSlot={handleSelectSlot}
                    />
                </div>
                {showSlots.show ? (
                <div className="col-3">
                    <h4>Selected Slots for {showSlots.date}</h4>
                    <div>
                        {showSlots.slots.length > 0 ? (
                        showSlots.slots.map((slot, index) => (
                            <ul key={index} className="p-2">
                                <li style={{fontSize:"17px"}}><i className="fa-solid fa-circle" />&nbsp;{slot.slot}</li>
                            </ul>
                        ))
                        ) : (
                        <div>No slots available for this date</div>
                        )}
                    </div>
                </div>
                ) : null}
                </div>
              </div>
            </div>
        </div>
    );
  }
  
  export default WorkHoursCalender;
  