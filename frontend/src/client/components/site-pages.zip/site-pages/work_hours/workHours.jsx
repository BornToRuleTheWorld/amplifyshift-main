import React, { useState, useEffect } from "react";
import axios from "axios";
import {AUTH_TOKEN, API_BASE_URL} from '../config';
import {convertTo12HourFormat,convertToUS} from "../utils";
import { Link } from "react-router-dom";

function WorkHours({ID, Role}) {
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(null)
  const [facData, setFacData] = useState([]);
  const [slotData, setSlotData] = useState([]);
  const [fetchSlot, setFetchSlot] = useState(false);
  const [slotID, setSlotID] = useState({slot_ids: []});
  
  var getUrl = ""
  var searchUrl = ""

  if (Role === "Job"){
    getUrl    = `${API_BASE_URL}/jobs/GetJobWorkHours/?JobID=${ID}`
    searchUrl = `${API_BASE_URL}/jobs/searchWorkHours/`
  }else{
    getUrl    = `${API_BASE_URL}/contract/GetContractHours/?ConID=${ID}`
    searchUrl = `${API_BASE_URL}/jobs/searchContractHours/`
  }

  // Fetch facility data using the user ID
  useEffect(() => {
    axios
      .get( getUrl, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': AUTH_TOKEN,
        }
      })
      .then((response) => {
        setFacData(response.data.data);
        const extractedSlotIds = response.data.data ? response.data.data.map(slot => slot.slot) : [];
        setSlotID({ slot_ids: extractedSlotIds });
        setFetchSlot(true)
      })
      .catch((err) => {
        console.error('Error fetching facility data:', err);
        setError(err.response.data.Result)
      });
  }, [ID, AUTH_TOKEN]);

  // Fetch slot data only if facData is available
  useEffect(() => {
    if (fetchSlot) {
      axios
        .post(`${API_BASE_URL}/GetSlot/`, slotID, {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': AUTH_TOKEN,
          }
        })
        .then((response) => {
          setSlotData(response.data.data);
        })
        .catch((err) => {
          console.error('Error fetching slot data:', err);
          setError(err.response.data.Result)
        });
    }
  }, [fetchSlot]);

  return (
    <div className="row">                      
            
            <div className="tab-content appointment-tab-content">
            <div
                className="tab-pane fade show active"
                id="pills-upcoming"
                role="tabpanel"
                aria-labelledby="pills-upcoming-tab"
            >
            
            {
                facData.length === 0 ? (
                    <tr><td colSpan="10">No work hours found</td></tr>
                ) : (
                facData.map((slotInfo) => {
                    const slotDetails = slotData.find(slot => slot.id === slotInfo.slot);
                    if (slotDetails) {
                        return (
                        <div className="appointment-wrap" key={slotInfo.id}>
                            <ul>
                                <li>
                                    <div className="patinet-information">
                                        <div className="patient-info">
                                            <p>Date</p>
                                            <h6>
                                                <i className="fa-solid fa-clock" />&nbsp;<Link to="#">{convertToUS(slotInfo.date,"Date")}</Link>
                                            </h6>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div className="patinet-information px-1">
                                        <div className="patient-info">
                                            <p>Time</p>
                                            <h6>
                                                <Link to="#" style={{fontSize:"20px"}}>{convertTo12HourFormat(slotDetails.start_hr)} - {convertTo12HourFormat(slotDetails.end_hr)}</Link>
                                            </h6>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                <div className="bottom-book-btn">
                                  <span className="btn btn-block w-100 btn-outline-success active">
                                    <i className="fa-solid fa-circle" />&nbsp;
                                    {slotInfo.status}{" "}
                                  </span>
                                </div>
                                </li>
                            </ul>
                        </div>
                )}}))}
            </div>
        </div>
    </div>
  );
}

export default WorkHours;
