
import axios from "axios";

const API_BASE_URL           = "http://localhost:8000/api"
const AUTH_TOKEN             = "Token 0c00522e81c6b8fc0e9f1776c6d371098241cce5"
const paginationDefaultCount = 10

let data = []
const fetchModules = async() => {
    try{
        const response = await axios.post(`${API_BASE_URL}/GetModules/`,
            { Modules: 
                [
                'Speciality',
                'Language',
                'Discipline',
                'DocSoftware',
                'WorkExp',
                'WorkSetting',
                'JobType',
                'VisitType',
                'Country', 
                'State',
                'QA'
                ]
            }, 
            {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': AUTH_TOKEN
                }
          });
          return response.data.data
    }catch(err){
        console.error("Modules fetch error:", err)
    }
}

data = await fetchModules();

console.log('moduleData',data)

const cntryOptions = data['Country'].map((cntry) => {
    return {
        value: cntry.id,
        label:cntry.cntry_name
    }
})

const stateOptions = data['State'].map((state) => {
    return {
        value: state.id,
        label: state.state_name
    }
})

const disciplineOptions = data['Discipline'].map((disp) => {
    return {
        value: disp.id,
        label: disp.disp_name
    }
})

const jobTypeOptions = data['JobType'].map((job) => {
    return {
        value: job.id,
        label: job.type_name
    }
})

const docOptions = data['DocSoftware'].map((doc) => {
    return {
        value: doc.id,
        label: doc.doc_soft_name
    }
})

const langOptions = data['Language'].map((lang) => {
    return {
        value: lang.id,
        label: lang.lang_name
    }
})

const specialtyOptions = data['Speciality'].map((spl) => {
    return {
        value: spl.id,
        label: spl.spl_name
    }
})

const visitType = data['VisitType'].map((visit) => {
    return {
        value: visit.id,
        label: visit.visit_name
    }
})

const workExperienceOptions = data['WorkExp'].map((work) => {
    return {
        value: work.id,
        label: work.wkr_name
    }
})

const workSettingOptions = data['WorkSetting'].map((setting) => {
    return{
        value:setting.id,
        label:setting.wrk_set_name
    }
})

const QAOptions = data['QA'].map((qa)=> {
    return {
        value:qa.id,
        label: qa.question
    }
})

// const disciplineOptions = [
//     { value: 1, label: 'PT' },
//     { value: 2, label: 'PTA' },
//     { value: 3, label: 'OT' },
//     { value: 4, label: 'COTA' },
//     { value: 5, label: 'SLP' },
// ];

// const docOptions = [
//     { value: 1, label: 'Net Health/Rehab Optima' },
//     { value: 2, label: 'Axxess' },
//     { value: 3, label: 'Kinnser' },
//     { value: 4, label: 'WebPT' },
//     { value: 5, label: 'Other' },
// ];

// const jobTypeOptions = [
//     { value: 1, label: 'Full Time' },
//     { value: 2, label: 'Part Time' },
//     { value: 3, label: 'PRN' },
//     { value: 4, label: 'Contract' },
// ]

// const langOptions = [
//     { value: 1, label: 'Spanish' },
//     { value: 2, label: 'French' },
//     { value: 3, label: 'English' },
//     { value: 4, label: 'Hindi' },
//     { value: 5, lablel: 'Others'}
// ];

// const specialtyOptions = [
//     { value: 1, label: 'Geriatrics' },
//     { value: 2, label: 'Pediatrics' },
//     { value: 3, label: 'Sports Rehab' },
//     { value: 4, label: 'Pelvic Floor Rehab' },
//     { value: 5, label: 'Orthopedics' },
//     { value: 6, label: 'Neuro' },
//     { value: 7, label: 'General' }
// ];

// const visitType = [
//     {value: 1, label:'Evaluation'},
//     {value: 2, label:'Recertification'},
//     {value: 3, label:'Discharge'},
//     {value: 4, label:'Regular Visit'}
// ]

// const workExperienceOptions = [
//     { value: 1, label: 'Skilled Nursing Facility' },
//     { value: 2, label: 'Home Health Services' },
//     { value: 3, label: 'Independent Living Facility' },
//     { value: 4, label: 'Outpatient' },
// ];
  
// const workSettingOptions = [
//     { value:  1, label: 'Hospital' },
//     { value:  2, label: 'Outpatient' },
//     { value:  3, label: 'SNF' },
//     { value:  4, label: 'Home Health' },
//     { value:  5, label: 'School' },
//     { value:  6, label: 'Remote' },
// ]
  

const yearOptions = [
    { value: '0-3', label: '0-3 yrs' },
    { value: '5-10', label: '5-10 yrs' },
    { value: '10+', label: '10+ yrs' },
];
 
const weeklyOptions = [
    { value: '0-10', label: '0-10 Visits' },
    { value: '10-15', label: '10-15 Visits' },
    { value: '15-25', label: '15-25 Visits' },
    { value: '25+', label: '25+ Visits' },
];

const boolOption = [
    { value: 'yes', label: 'Yes' },
    { value: 'no', label: 'No' },
]

const statusOptions = [
    {value:"Inactive", label:"Inactive"},
    {value:"Active", label:"Active"},
]

//react-select custom style for placeholder
const customStyles = {
    placeholder: (base) => ({
      ...base,
      textAlign: 'center',
    }),
    singleValue: (base) => ({
      ...base,
      textAlign: 'left',
    }),
    option: (base) => ({
      ...base,
      textAlign: 'left',
    }),
  };


const modulesOption = [
    disciplineOptions, 
    docOptions, 
    jobTypeOptions, 
    langOptions, 
    specialtyOptions, 
    visitType, 
    workExperienceOptions, 
    workSettingOptions,
    cntryOptions,
    stateOptions,
    QAOptions
]

modulesOption.forEach((module, index) => {
    modulesOption[index] = module.sort((a, b) => (a.label < b.label ? -1 : a.label > b.label ? 1 : 0));
});

export { API_BASE_URL, AUTH_TOKEN, disciplineOptions, docOptions, jobTypeOptions, langOptions,specialtyOptions, visitType, workExperienceOptions, workSettingOptions, yearOptions, weeklyOptions, boolOption, statusOptions, cntryOptions, stateOptions, QAOptions, paginationDefaultCount, fetchModules, customStyles };