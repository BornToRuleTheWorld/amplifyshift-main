import React, { useEffect, useState } from "react";
import SiteHeader from "../../../home/header";
import SiteFooter from "../../../home/footer";
import StickyBox from "react-sticky-box";
import Doctors from "./doctors";
import { Link } from "react-router-dom";
import { DatePicker } from "antd";
import Searchfilter from "./searchfilter";
import ImageWithBasePath from "../../../../../../core/img/imagewithbasebath";
import axios from "axios";
import { API_BASE_URL, AUTH_TOKEN, disciplineOptions } from "../../../config";
import Select from "react-select";
import { convertToUS } from "../../../utils";
import { parse } from 'date-fns';

const FacilitySearch = (props) => {
  
  let jobID = ""
  if (localStorage.getItem('searchJobID')){
    jobID = atob(localStorage.getItem('searchJobID')) || "";
  }
  const setJobSearch = localStorage.getItem('setJobSearch') || "";
  const currentUser = atob(localStorage.getItem('userID')) || "";
  const facID = atob(localStorage.getItem('RecordID')) || "";

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [value, onChange] = useState(new Date());
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [search, setSearch] = useState(false);
  const [calendarDates, setCalendarDates] = useState([]);
  const [selectedSchedule, setSelectedSchedule] = useState([]);
  const [profData, setProfData] = useState([]);

  const [formData, setFormData] = useState({
    facility_id:facID,
    zipcode: '',
    license: '',
    dates:{
        start: startDate,
        end:endDate,
        dates:calendarDates,
        schedule:selectedSchedule
    },
    years_of_exp: '',
    cpr_bls:'',
    work_setting: "",
    discipline: "",
    languages: "",
    job_type: "",
    speciality: "",
    visit_type:"",
    pay:"",
    result_count:"",
    professional_ids:[]
  });

  const [jobRequest, setJobRequest] = useState({
    job:jobID,
    professional:'',
    status:"New",
    created_by:currentUser
  });

  const searchData = {
      prof_zip_primary: formData.zipcode,
      prof_discipline:formData.discipline,
      prof_langs:formData.languages,
      prof_speciality:formData.speciality,
      prof_years_in: formData.years_of_exp,
      job_id:jobID
  }

  useEffect(() => {
    if(setJobSearch){
      axios
        .get(`${API_BASE_URL}/jobs/GetJobs/?JobID=${jobID}&method=single`, {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': AUTH_TOKEN,
          }
      })
      .then((response) => {
          const jobData = response.data.data;
          console.log(jobData)
          if(jobData){
            setFormData(prevState => ({
              ...prevState,
              zipcode: jobData.zipcode || '',
              discipline: jobData.discipline || '',
              languages: jobData.languages || '',
              speciality: jobData.speciality || '',
              years_of_exp: jobData.years_of_exp || '',
              cpr_bls:jobData.cpr_bls || '',
              work_setting:jobData.work_setting || '',
              visit_type:jobData.visit_type || '',
              pay:jobData.pay || '',
              job_type:jobData.job_type || '',
          }));
          setStartDate(parse(jobData.start_date, 'yyyy-MM-dd', new Date()))
          setEndDate(parse(jobData.end_date, 'yyyy-MM-dd', new Date()))
        }
          
      })
      .catch((err) => {
          console.error('Error:', err);
      });
    }
  }, [jobID]);

  const [minValue, setMinValue] = useState(10);
  const [maxValue, setMaxValue] = useState(5000);

  useEffect(() => {
    if (document.getElementById("price-range")) {
      setMinValue(10);
      setMaxValue(10000);

      const slider = document.getElementById("price-range");
      slider.addEventListener("input", handleSliderChange);

      return () => {
        slider.removeEventListener("input", handleSliderChange);
      };
    }
  }, []);

  const handleSliderChange = (event) => {
    const min = parseInt(event.target.value.split(",")[0]);
    const max = parseInt(event.target.value.split(",")[1]);

    setMinValue(min);
    setMaxValue(max);
  };

    const handleSubmit = async (e) => {
      e.preventDefault();
      setIsLoading(true);
      setError(null);
      localStorage.removeItem('setJobSearch');
      facilitySearch();                                     
    };

    const facilitySearch = async () => {
        try {
            const response = await axios.post(
                `${API_BASE_URL}/facility/facilitySearch/`,
                searchData,
                {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': AUTH_TOKEN,
                },
                }
            );
            console.log('Search data:', response.data);
            setProfData(response.data.data);

            setFormData(prev => ({
                ...prev,
                professional_ids:response.data.prof_ids,
                result_count:response.data.count
            }));

            setSearch(true)

        } catch (err) {
            console.error('Search Error:', err);
            setError('An error occurred while fetching data');
        } finally {
            setIsLoading(false);
        }
    }
    useEffect(() => {
      if (search){
        try {
          const response = axios.post(
            `${API_BASE_URL}/facility/CreateFacSearch/`,
            formData,
            {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': AUTH_TOKEN,
            },
            }
          );
        } catch (err) {
            setError(err.response.data.Result || 'An error occurred while fetching data');
        } finally {
            setSearch(false);
        }
      }
    },[search])

    const handleInputChange = (e) => {
      const { name, value } = e.target;
      setFormData(prevState => ({
      ...prevState,
      [name]: value
      }));
    };

    const handleStartDate = (date) =>{ console.log(date); setStartDate(date);}
    const handleEndDate   = (date) =>{ console.log(date); setEndDate(date);}

    const handleSelectChange = (selectedOptions, fieldName) => {
      setFormData(prevState => ({
        ...prevState,
        [fieldName]: selectedOptions
      }));
    };
    console.log("profData :",profData)
    console.log("formData", formData)
    console.log('startDate:',startDate)
    console.log('endDate:',endDate)
  return (
    <div className="main-wrapper">
      <SiteHeader {...props} />

      {/* Breadcrumb */}
      <div className="breadcrumb-bar overflow-visible">
        <div className="container">
          <div className="row align-items-center inner-banner">
            <div className="col-md-12 col-12 text-center">
              <nav aria-label="breadcrumb" className="page-breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">
                    <Link to="/home">
                      <i className="isax isax-home-15" />
                    </Link>
                  </li>
                  <li className="breadcrumb-item">Facility</li>
                  <li className="breadcrumb-item active">Search</li>
                </ol>
                <h2 className="breadcrumb-title">Professional Search</h2>
              </nav>
            </div>
          </div>
          <div className="bg-primary-gradient rounded-pill doctors-search-box">
            <div className="search-box-one rounded-pill">
              <form onSubmit={handleSubmit}>
                <div className="search-input search-line">
                  <i className="isax isax-hospital5 bficon" />
                  <div className=" mb-0 h-25">
                  <Select
                    className="form-control"
                    name="discipline"
                    options={disciplineOptions}
                    value={disciplineOptions.filter( disp => disp.value == formData.discipline)}
                    onChange={(selected) => handleSelectChange(selected.value, 'discipline')}
                    placeholder="Select"
                    isClearable={true}
                    isSearchable={true}
                  />
                    {/* <input
                      type="text"
                      className="form-control"
                      placeholder="Search for Discipline"
                    /> */}
                  </div>
                </div>
                <div className="search-input search-map-line">
                  <i className="isax isax-location5" />
                  <div className=" mb-0">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Zipcode"
                      name="zipcode"
                      value={formData.zipcode}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
                <div className="search-input search-calendar-line">
                  <i className="isax isax-calendar-tick5" />
                  <div className=" mb-0">
                    <DatePicker
                      className="form-control datetimepicker"
                      placeholder="Start Date"
                      selected={startDate}
                      onChange={handleStartDate}
                      dateFormat="MM/dd/yyyy"
                    />
                  </div>
                </div>
                <div className="search-input search-calendar-line">
                  <i className="isax isax-calendar-tick5" />
                  <div className=" mb-0">
                    <DatePicker
                      className="form-control"
                      placeholder="End Date"
                      selected={endDate}
                      onChange={handleEndDate}
                      dateFormat="MM/dd/yyyy"
                    />
                  </div>
                </div>
                <div className="form-search-btn">
                  <button
                    className="btn btn-primary d-inline-flex align-items-center rounded-pill"
                    type="submit"
                  >
                    <i className="isax isax-search-normal-15 me-2" />
                    Search
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div className="breadcrumb-bg">
          <ImageWithBasePath
            src="assets/img/bg/breadcrumb-bg-01.png"
            alt="img"
            className="breadcrumb-bg-01"
          />
          <ImageWithBasePath
            src="assets/img/bg/breadcrumb-bg-02.png"
            alt="img"
            className="breadcrumb-bg-02"
          />
          <ImageWithBasePath
            src="assets/img/bg/breadcrumb-icon.png"
            alt="img"
            className="breadcrumb-bg-03"
          />
          <ImageWithBasePath
            src="assets/img/bg/breadcrumb-icon.png"
            alt="img"
            className="breadcrumb-bg-04"
          />
        </div>
      </div>
      {/* /Breadcrumb */}

      <div className="doctor-content content">
        <div className="container">
          <div className="row">
            <div className="col-xl-12 col-lg-12 map-view">
              <div className="row">
                <div className="col-lg-3  theiaStickySidebar">
                  <StickyBox offsetTop={20} offsetBottom={20}>
                   <Searchfilter data={formData}/>
                  </StickyBox>
                </div>

                <div className="col-lg-9">
                  <Doctors data={profData} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <SiteFooter {...props} />
    </div>
  );
};

export default FacilitySearch;
