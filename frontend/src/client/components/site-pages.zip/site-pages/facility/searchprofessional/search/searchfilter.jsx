import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import ImageWithBasePath from "../../../../../../core/img/imagewithbasebath";
import { DatePicker, Slider } from "antd";
import { specialtyOptions } from "../../../config";

const Searchfilter = ({data}) => {
    const formatter = (value) => `$${value}`;
  
    const [showMenu,setShowMenu] = useState(false)
      const [showMenu2,setShowMenu2] = useState(false)
      const [showMenu3,setShowMenu3] = useState(false)
      const [showMenu4,setShowMenu4] = useState(false)

      const handleCheckboxChange = (event) => {
        const { id, checked } = event.target;
        const specialityValue = id.split('-')[2];
    
        setFormData(prevState => {
            const updatedSpecialities = checked
                ? [...prevState.speciality, specialityValue]
                : prevState.speciality.filter(speciality => speciality !== specialityValue);
    
            return {
                ...prevState,
                speciality: updatedSpecialities
            };
        });
      };
    

  return (
    <div className="card filter-lists">
    <div className="card-header">
      <div className="d-flex align-items-center filter-head justify-content-between">
        <h4>Filter</h4>
        <Link to="#" className="text-secondary text-decoration-underline">
          Clear All
        </Link>
      </div>
      <div className="filter-input">
        <div className="position-relative input-icon">
          <input type="text" className="form-control" />
          <span>
            <i className="isax isax-search-normal-1" />
          </span>
        </div>
      </div>
    </div>
    <div className="card-body p-0">
      {/* <div className="accordion-item border-bottom">
        <div className="accordion-header" id="heading1">
          <div
            className="accordion-button"
            data-bs-toggle="collapse"
            data-bs-target="#collapse1"
            aria-controls="collapse1"
            role="button"
          >
            <div className="d-flex align-items-center w-100">
              <h5>Specialities</h5>
              <div className="ms-auto">
                <span>
                  <i className="fas fa-chevron-down" />
                </span>
              </div>
            </div>
          </div>
        </div>
        <div
          id="collapse1"
          className="accordion-collapse show"
          aria-labelledby="heading1"
        >
          <div className="accordion-body pt-3">
            <div className="d-flex align-items-center justify-content-between mb-2">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  defaultValue=""
                  id="checkebox-sm2"
                  defaultChecked=""
                />
                <label
                  className="form-check-label"
                  htmlFor="checkebox-sm2"
                >
                  General
                </label>
              </div>
              <span className="filter-badge">21</span>
            </div>
            <div className="d-flex align-items-center justify-content-between mb-2">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  defaultValue=""
                  id="checkebox-sm3"
                />
                <label
                  className="form-check-label"
                  htmlFor="checkebox-sm3"
                >
                  Neuro
                </label>
              </div>
              <span className="filter-badge">21</span>
            </div>
            <div className="d-flex align-items-center justify-content-between mb-2">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  defaultValue=""
                  id="checkebox-sm4"
                />
                <label
                  className="form-check-label"
                  htmlFor="checkebox-sm4"
                >
                  Orthopedics
                </label>
              </div>
              <span className="filter-badge">21</span>
            </div>
            
            <div className="view-content" >
              <div className="viewall-one" style={{ display: !showMenu ? 'none' : 'block' }}>
                <div className="d-flex align-items-center justify-content-between mb-2">
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      defaultValue=""
                      id="checkebox-sm5"
                    />
                    <label
                      className="form-check-label"
                      htmlFor="checkebox-sm5"
                    >
                      Pelvic Floor Rehab
                    </label>
                  </div>
                <span className="filter-badge">21</span>
              </div>
              <div className="d-flex align-items-center justify-content-between mb-2">
                <div className="form-check">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    defaultValue=""
                    id="checkebox-sm6"
                  />
                  <label
                    className="form-check-label"
                    htmlFor="checkebox-sm6"
                  >
                    Sports Rehab
                  </label>
                </div>
                <span className="filter-badge">21</span>
              </div>
                <div className="d-flex align-items-center justify-content-between mb-2">
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      defaultValue=""
                      id="checkebox-sm9"
                    />
                    <label
                      className="form-check-label"
                      htmlFor="checkebox-sm9"
                    >
                      Pediatrics
                    </label>
                  </div>
                  <span className="filter-badge">21</span>
                </div>
                <div className="d-flex align-items-center justify-content-between mb-2">
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      defaultValue=""
                      id="checkebox-sm10"
                    />
                    <label
                      className="form-check-label"
                      htmlFor="checkebox-sm10"
                    >
                      Geriatrics
                    </label>
                  </div>
                  <span className="filter-badge">21</span>
                </div>
              </div>
              <div className="view-all">
                <Link
                  to="#" onClick={()=>{setShowMenu(!showMenu)}}
                  className="viewall-button-one text-secondary text-decoration-underline"
                >
                  {showMenu ?'View Less':'View More'}
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div> */}
      <div className="accordion-item border-bottom">
        <div className="accordion-header" id="heading1">
          <div
            className="accordion-button"
            data-bs-toggle="collapse"
            data-bs-target="#collapse1"
            aria-controls="collapse1"
            role="button"
          >
            <div className="d-flex align-items-center w-100">
              <h5>Specialities</h5>
              <div className="ms-auto">
                <span>
                  <i className="fas fa-chevron-down" />
                </span>
              </div>
            </div>
          </div>
        </div>
        <div
          id="collapse1"
          className="accordion-collapse show"
          aria-labelledby="heading1"
        >
        <div className="accordion-body pt-3">
          {specialtyOptions.slice(0, 3).map((option) => (
            <div key={option.value} className="d-flex align-items-center justify-content-between mb-2">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  id={`checkbox-sm-${option.value}`}
                  value = {option.value}
                  onChange={handleCheckboxChange}
                />
                <label
                  className="form-check-label"
                  htmlFor={`checkbox-sm-${option.value}`}
                >
                  {option.label}
                </label>
              </div>
            </div>
          ))}
          <div className="view-content">
            <div className="viewall-one" style={{ display: !showMenu ? 'none' : 'block' }}>
              {specialtyOptions.slice(3).map((option) => (
                <div key={option.value} className="d-flex align-items-center justify-content-between mb-2">
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id={`checkbox-sm-${option.value}`}
                      value = {option.value}
                      onChange={handleCheckboxChange}
                    />
                    <label
                      className="form-check-label"
                      htmlFor={`checkbox-sm-${option.value}`}
                    >
                      {option.label}
                    </label>
                  </div>
                </div>
              ))}
            </div>
            <div className="view-all">
              <Link
                to="#"
                onClick={() => setShowMenu(!showMenu)}
                className="viewall-button-one text-secondary text-decoration-underline"
              >
                {showMenu ? 'View Less' : 'View More'}
              </Link>
            </div>
          </div>
        </div>
      </div>
      </div>
      <div className="accordion-item border-bottom">
        <div className="accordion-header" id="heading5">
          <div
            className="accordion-button"
            data-bs-toggle="collapse"
            data-bs-target="#collapse5"
            aria-controls="collapse5"
            role="button"
          >
            <div className="d-flex align-items-center w-100">
              <h5>Experience</h5>
              <div className="ms-auto">
                <span>
                  <i className="fas fa-chevron-down" />
                </span>
              </div>
            </div>
          </div>
        </div>
        <div
          id="collapse5"
          className="accordion-collapse show"
          aria-labelledby="heading5"
        >
          <div className="accordion-body pt-3">
            <div className="d-flex align-items-center justify-content-between mb-2">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  defaultValue=""
                  id="checkebox-sm21"
                  defaultChecked=""
                />
                <label
                  className="form-check-label"
                  htmlFor="checkebox-sm21"
                >
                  0-3 Years
                </label>
              </div>
            </div>
            <div className="d-flex align-items-center justify-content-between mb-2">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  defaultValue=""
                  id="checkebox-sm22"
                />
                <label
                  className="form-check-label"
                  htmlFor="checkebox-sm22"
                >
                  3-5 Years
                </label>
              </div>
            </div>
            
            <div className="view-content">
              <div className="viewall-3" style={{display: !showMenu3 ?'none':'block'}}>
                <div className="d-flex align-items-center justify-content-between mb-2">
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      defaultValue=""
                      id="checkebox-sm23"
                    />
                    <label
                      className="form-check-label"
                      htmlFor="checkebox-sm23"
                    >
                      5-10 Years
                    </label>
                  </div>
                </div>
                <div className="d-flex align-items-center justify-content-between mb-2">
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      defaultValue=""
                      id="checkebox-sm24"
                    />
                    <label
                      className="form-check-label"
                      htmlFor="checkebox-sm24"
                    >
                      10+ Years
                    </label>
                  </div>
                </div>
              </div>
              <div className="view-all">
                <Link
                  to="#" onClick={()=>{setShowMenu3(!showMenu3)}}
                  className="viewall-button-3 text-secondary text-decoration-underline"
                >
                 {showMenu2 ?'View Less':'View All'}
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="accordion-item border-bottom">
        <div className="accordion-header" id="heading6">
          <div
            className="accordion-button"
            data-bs-toggle="collapse"
            data-bs-target="#collapse6"
            aria-controls="collapse6"
            role="button"
          >
            <div className="d-flex align-items-center w-100">
              <h5>Visit type</h5>
              <div className="ms-auto">
                <span>
                  <i className="fas fa-chevron-down" />
                </span>
              </div>
            </div>
          </div>
        </div>
        <div
          id="collapse6"
          className="accordion-collapse show"
          aria-labelledby="heading6"
        >
          <div className="accordion-body pt-3">
            <div className="d-flex align-items-center justify-content-between mb-2">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  defaultValue=""
                  id="checkebox-sm25"
                  defaultChecked=""
                />
                <label
                  className="form-check-label"
                  htmlFor="checkebox-sm25"
                >
                  Regular Visit
                </label>
              </div>
            </div>
            <div className="d-flex align-items-center justify-content-between mb-2">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  defaultValue=""
                  id="checkebox-sm26"
                />
                <label
                  className="form-check-label"
                  htmlFor="checkebox-sm26"
                >
                  Discharge
                </label>
              </div>
            </div>
            <div className="d-flex align-items-center justify-content-between mb-2">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  defaultValue=""
                  id="checkebox-sm27"
                />
                <label
                  className="form-check-label"
                  htmlFor="checkebox-sm27"
                >
                  Recertification
                </label>
              </div>
            </div>
            <div className="view-content">
              <div className="viewall-4" style={{ display: !showMenu4 ? 'none' : 'block' }}>
                <div className="d-flex align-items-center justify-content-between mb-2">
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      defaultValue=""
                      id="checkebox-sm28"
                    />
                    <label
                      className="form-check-label"
                      htmlFor="checkebox-sm28"
                    >
                      Evaluation
                    </label>
                  </div>
                </div>
              </div>
              <div className="view-all">
                <Link
                  to="#" onClick={()=>{setShowMenu4(!showMenu4)}}
                  className="viewall-button-4 text-secondary text-decoration-underline"
                >
                  {showMenu4 ?'View Less':'View More'}
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="accordion-item border-bottom">
        <div className="accordion-header" id="heading7">
          <div
            className="accordion-button"
            data-bs-toggle="collapse"
            data-bs-target="#collapse7"
            aria-controls="collapse7"
            role="button"
          >
            <div className="d-flex align-items-center w-100">
              <h5>Job type</h5>
              <div className="ms-auto">
                <span>
                  <i className="fas fa-chevron-down" />
                </span>
              </div>
            </div>
          </div>
        </div>
        <div
          id="collapse7"
          className="accordion-collapse show"
          aria-labelledby="heading7"
        >
          <div className="accordion-body pt-3">
            <div className="d-flex align-items-center justify-content-between mb-2">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  defaultValue=""
                  id="checkebox-sm30"
                  defaultChecked=""
                />
                <label
                  className="form-check-label"
                  htmlFor="checkebox-sm30"
                >
                  Contract
                </label>
              </div>
            </div>
            <div className="d-flex align-items-center justify-content-between mb-2">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  defaultValue=""
                  id="checkebox-sm31"
                />
                <label
                  className="form-check-label"
                  htmlFor="checkebox-sm31"
                >
                  	PRN
                </label>
              </div>
            </div>
            <div className="d-flex align-items-center justify-content-between mb-2">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  defaultValue=""
                  id="checkebox-sm32"
                />
                <label
                  className="form-check-label"
                  htmlFor="checkebox-sm32"
                >
                  Part Time
                </label>
              </div>
            </div>
            <div className="view-content">
              <div className="viewall-4" style={{ display: !showMenu4 ? 'none' : 'block' }}>
              <div className="d-flex align-items-center justify-content-between">
                <div className="form-check">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    defaultValue=""
                    id="checkebox-sm33"
                  />
                  <label
                    className="form-check-label"
                    htmlFor="checkebox-sm33"
                  >
                    Full Time
                  </label>
                </div>
              </div>
              </div>
              <div className="view-all">
                <Link
                  to="#" onClick={()=>{setShowMenu4(!showMenu4)}}
                  className="viewall-button-4 text-secondary text-decoration-underline"
                >
                  {showMenu4 ?'View Less':'View More'}
                </Link>
              </div>
            </div>
            
          </div>
        </div>
      </div>
      <div className="accordion-item border-bottom">
        <div className="accordion-header" id="heading8">
          <div
            className="accordion-button"
            data-bs-toggle="collapse"
            data-bs-target="#collapse8"
            aria-controls="collapse8"
            role="button"
          >
            <div className="d-flex align-items-center w-100">
              <h5>Languages</h5>
              <div className="ms-auto">
                <span>
                  <i className="fas fa-chevron-down" />
                </span>
              </div>
            </div>
          </div>
        </div>
        <div
          id="collapse8"
          className="accordion-collapse show"
          aria-labelledby="heading8"
        >
          <div className="accordion-body pt-3">
            <div className="d-flex align-items-center justify-content-between mb-2">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  defaultValue=""
                  id="checkebox-sm34"
                  defaultChecked=""
                />
                <label
                  className="form-check-label"
                  htmlFor="checkebox-sm34"
                >
                  English
                </label>
              </div>
            </div>
            <div className="d-flex align-items-center justify-content-between mb-2">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  defaultValue=""
                  id="checkebox-sm35"
                />
                <label
                  className="form-check-label"
                  htmlFor="checkebox-sm35"
                >
                  French
                </label>
              </div>
            </div>
            <div className="d-flex align-items-center justify-content-between mb-2">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  defaultValue=""
                  id="checkebox-sm36"
                />
                <label
                  className="form-check-label"
                  htmlFor="checkebox-sm36"
                >
                  Spanish
                </label>
              </div>
            </div>
            <div className="view-content">
              <div className="viewall-4" style={{ display: !showMenu4 ? 'none' : 'block' }}>
                <div className="d-flex align-items-center justify-content-between mb-2">
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      defaultValue=""
                      id="checkebox-sm28"
                    />
                    <label
                      className="form-check-label"
                      htmlFor="checkebox-sm28"
                    >
                      Hindi
                    </label>
                  </div>
                </div>
              </div>
              <div className="viewall-4" style={{ display: !showMenu4 ? 'none' : 'block' }}>
                <div className="d-flex align-items-center justify-content-between mb-2">
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      defaultValue=""
                      id="checkebox-sm28"
                    />
                    <label
                      className="form-check-label"
                      htmlFor="checkebox-sm28"
                    >
                      Others
                    </label>
                  </div>
                </div>
              </div>
              <div className="view-all">
                <Link
                  to="#" onClick={()=>{setShowMenu4(!showMenu4)}}
                  className="viewall-button-4 text-secondary text-decoration-underline"
                >
                  {showMenu4 ?'View Less':'View More'}
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="accordion-item border-bottom">
        <div className="accordion-header" id="heading8">
          <div
            className="accordion-button"
            data-bs-toggle="collapse"
            data-bs-target="#collapse8"
            aria-controls="collapse8"
            role="button"
          >
            <div className="d-flex align-items-center w-100">
              <h5>License</h5>
              <div className="ms-auto">
                <span>
                  <i className="fas fa-chevron-down" />
                </span>
              </div>
            </div>
          </div>
        </div>
        <div
          id="collapse8"
          className="accordion-collapse show"
          aria-labelledby="heading8"
        >
          <div className="accordion-body pt-3">
            <div className="d-flex align-items-center justify-content-between mb-2">
              <div className="form-check">
                <input
                  name = "License"
                  className="form-check-input"
                  type="radio"
                  defaultValue=""
                  id="checkebox-sm34"
                  defaultChecked=""
                />
                <label
                  className="form-check-label"
                  htmlFor="checkebox-sm34"
                >
                  Yes
                </label>
              </div>
            </div>
            <div className="d-flex align-items-center justify-content-between mb-2">
              <div className="form-check">
                <input
                  name = "License"
                  className="form-check-input"
                  type="radio"
                  defaultValue=""
                  id="checkebox-sm35"
                />
                <label
                  className="form-check-label"
                  htmlFor="checkebox-sm35"
                >
                  No
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="accordion-item border-bottom">
        <div className="accordion-header" id="heading8">
          <div
            className="accordion-button"
            data-bs-toggle="collapse"
            data-bs-target="#collapse8"
            aria-controls="collapse8"
            role="button"
          >
            <div className="d-flex align-items-center w-100">
              <h5>CPR/BLS</h5>
              <div className="ms-auto">
                <span>
                  <i className="fas fa-chevron-down" />
                </span>
              </div>
            </div>
          </div>
        </div>
        <div
          id="collapse8"
          className="accordion-collapse show"
          aria-labelledby="heading8"
        >
          <div className="accordion-body pt-3">
            <div className="d-flex align-items-center justify-content-between mb-2">
              <div className="form-check">
                <input
                  name = "CPR/BLS"
                  className="form-check-input"
                  type="radio"
                  defaultValue=""
                  id="checkebox-sm34"
                  defaultChecked=""
                />
                <label
                  className="form-check-label"
                  htmlFor="checkebox-sm34"
                >
                  Yes
                </label>
              </div>
            </div>
            <div className="d-flex align-items-center justify-content-between mb-2">
              <div className="form-check">
                <input
                  name = "CPR/BLS"
                  className="form-check-input"
                  type="radio"
                  defaultValue=""
                  id="checkebox-sm35"
                />
                <label
                  className="form-check-label"
                  htmlFor="checkebox-sm35"
                >
                  No
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  );
};

export default Searchfilter;
