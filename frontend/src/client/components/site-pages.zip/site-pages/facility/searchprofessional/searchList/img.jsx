
export { default as IMG01} from '../../../assets/images/doctor-01.jpg';
export { default as IMG02} from '../../../assets/images/doctor-02.jpg';
export { default as IMG03} from '../../../assets/images/doctor-03.jpg';
export { default as IMG04} from '../../../assets/images/doctor-04.jpg';
export { default as IMG05} from '../../../assets/images/doctor-05.jpg';

export { default as IMG06} from '../../../assets/images/feature-01.jpg';
export { default as IMG07} from '../../../assets/images/feature-02.jpg';
export { default as IMG08} from '../../../assets/images/feature-03.jpg';
export { default as IMG09} from '../../../assets/images/feature-04.jpg';
export { default as IMG10} from '../../../assets/images/specialities-05.png';
export { default as IMG11} from '../../../assets/images/specialities-04.png';
export { default as IMG12} from '../../../assets/images/specialities-03.png';
export { default as IMG13} from '../../../assets/images/specialities-05.png';

