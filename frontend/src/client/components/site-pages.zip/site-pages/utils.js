export const convertToUS = (date,format) => {

    var dateTime = false
    if (format === "DateTime"){ dateTime = true }
    
    const options = {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "numeric",
        second: "numeric",
        hour12: true,
        timeZone: "America/Los_Angeles",
    };
    
    const newDate = new Date(date)
    const convertedDate = new Intl.DateTimeFormat('en-US', (dateTime) ? options : {}).format(newDate)
    return convertedDate
}

export const convertTo12HourFormat = (time24) => {
    if (!time24) return '';
    const [hours, minutes] = time24.split(':');
    const period = hours >= 12 ? 'PM' : 'AM';
    const hours12 = hours % 12 || 12;
    const minutesFormatted = minutes.padStart(2, '0');
    return `${hours12}:${minutesFormatted} ${period}`;
};
