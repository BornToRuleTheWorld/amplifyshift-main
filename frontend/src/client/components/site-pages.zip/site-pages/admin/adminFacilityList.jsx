import React, { useState, useEffect } from "react";
import axios from "axios";
import { API_BASE_URL, AUTH_TOKEN, disciplineOptions, specialtyOptions, visitType, jobTypeOptions, paginationDefaultCount, workSettingOptions } from "../config";
import { convertToUS } from "../utils";
import Pagination from '../pagination';
import { FaTimesCircle, FaEye, FaSearch, FaHourglassHalf, FaPlusCircle } from "react-icons/fa";
import { Link, useHistory } from "react-router-dom";
import SiteHeader from "../home/header.jsx";
import SiteFooter from "../home/footer.jsx";
import { doctor_thumb_01, doctor_thumb_02, doctor_thumb_03, doctor_thumb_05, doctor_thumb_07, doctor_thumb_08, doctor_thumb_09, logo } from "../../imagepath.jsx";
import ImageWithBasePath from "../../../../core/img/imagewithbasebath.jsx";
import AdminPagination from "./AdminPagination.jsx";

const AdminFacilityList = (props) => {

  const [userData, setUserData] = useState([]);
  const [error, setError] = useState(null);
  const [sucMessage, setSucMessage] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage, setRecordsPerPage] = useState(paginationDefaultCount);
  //const [recordsPerPage, setRecordsPerPage] = useState(5);
  const [totalPages, setTotalPages] = useState(0);

  const fetchUsers = async () => {
    const data = {
      CurrentPage:currentPage,
      RecordsPerPage:recordsPerPage
    }
    console.log('ipData', data);
    try {
      const response = await axios.post(`${API_BASE_URL}/facility/GetFacilities/`,data, {
        headers: {
          "Content-Type": "application/json",
          'Authorization': AUTH_TOKEN
        },
      });
      console.log('response', response);

      if(response?.status === 200){
        if(response.data.CurrentPage)setCurrentPage(response.data.CurrentPage);
        if(response.data.RecordsPerPage)setRecordsPerPage(response.data.RecordsPerPage);
        if(response.data.TotalCount)setTotalPages(response.data.TotalCount);
        if(response.data.data.length > 0){
          setUserData(response.data.data);
          setSucMessage('Facilities list fetched successfully');
          setError(null); 
        }
        else{
          setUserData([]);
          setSucMessage('Empty facility data');     
          setError(null); 
        }
               
      }


    } catch (err) {
      console.log('responseError', err);
      setError("An error occurred while fetching facilities list");
      setSucMessage(null);
    }
  };

  useEffect(() => {
    fetchUsers(); 
  }, [currentPage]);

  //console.log("totalPages",totalPages);
  //console.log("recordsPerPage",recordsPerPage);
  
  return (
    <div>
      <SiteHeader {...props} />
      <>
        {/* Breadcrumb */}
        <div className="breadcrumb-bar">
          <div className="container">
            <div className="row align-items-center inner-banner">
              <div className="col-md-12 col-12 text-center">
                <nav aria-label="breadcrumb" className="page-breadcrumb">
                  <ol className="breadcrumb">
                    <li className="breadcrumb-item">
                      <a href="/home">
                        <i className="isax isax-home-15" />
                      </a>
                    </li>
                    <li className="breadcrumb-item" aria-current="page">
                      Facilities
                    </li>
                    <li className="breadcrumb-item active">Facilities</li>
                  </ol>
                  <h2 className="breadcrumb-title">Facilities</h2>
                </nav>
              </div>
            </div>
          </div>


          <div className="breadcrumb-bg">
            <ImageWithBasePath
              src="assets/img/bg/breadcrumb-bg-01.png"
              alt="img"
              className="breadcrumb-bg-01"
            />
            <ImageWithBasePath
              src="assets/img/bg/breadcrumb-bg-02.png"
              alt="img"
              className="breadcrumb-bg-02"
            />
            <ImageWithBasePath
              src="assets/img/bg/breadcrumb-icon.png"
              alt="img"
              className="breadcrumb-bg-03"
            />
            <ImageWithBasePath
              src="assets/img/bg/breadcrumb-icon.png"
              alt="img"
              className="breadcrumb-bg-04"
            />
          </div>
        </div>
        {/* /Breadcrumb */}
      </>
      <div style={{ margin: "10px" }}>
        <div className="search-header">
          <div className="search-field">
            <input
              type="text"
              className="form-control"
              placeholder="Search"
            />
            <span className="search-icon">
              <i className="fa-solid fa-magnifying-glass" />
            </span>
          </div>

        </div>
        <div className="custom-table">

        {sucMessage?(
                  <div className="alert alert-success alert-dismissible fade show" role="alert"                  
                  >
                    {sucMessage} <button type="button" className="btn-close" data-bs-dismiss="alert" aria-label="Close"><span aria-hidden="true"></span></button>
                  </div>
        ):''}

        {error?(
                  <div className="alert alert-danger alert-dismissible fade show" role="alert">
                    {error} <button type="button" className="btn-close" data-bs-dismiss="alert" aria-label="Close"><span aria-hidden="true"></span></button>
                  </div>
        ):''}

          <div className="table-responsive">
            <table className="table table-center mb-0">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Last Name</th>
                  <th>Email</th>
                  <th>Contact Number</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>



                {userData.length === 0 ? (
                  <tr><td colSpan="10" style={{ fontSize: "19px", padding: "15px",}}>Loading...</td></tr>
                ) : (
                  userData.map((user) => (
                    <tr key={user.id}>
                      <td>{user.fac_first_name}</td>
                      <td>{user.fac_last_name}</td>
                      <td>{user.fac_email}</td>                      
                      <td>{user.fac_contact_num}</td>
                      <td>{user.fac_status}</td>
                      <td>
                        <div className="action-item">
                          <Link to="#">
                            <i className="isax isax-edit-2" />
                          </Link>
                          <Link to="#">
                            <i className="isax isax-eye4" />
                          </Link>
                          <Link to="#">
                            <i className="isax isax-trash" />
                          </Link>
                        </div>
                      </td>
                    </tr>
                  ))
                )}

              </tbody>
            </table>
          </div>
        </div>
      </div>

      {recordsPerPage < totalPages ? <AdminPagination totalPages={totalPages} recordsPerPage={recordsPerPage} setCurrentPage={setCurrentPage} currentPage={currentPage} /> : ''}
      

      <SiteFooter />

    </div>
  );
};

export default AdminFacilityList;
