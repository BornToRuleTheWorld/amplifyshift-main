
export { default as IMG01} from '../../../assets/images/logo.png';
export {default as vect1} from '../../../assets/images/icons/vect-01.png'
export {default as vect2} from '../../../assets/images/icons/vect-02.png'
export {default as vect3} from '../../../assets/images/icons/vect-03.png'
export {default as feature7} from "../../../assets/images/features/feature-07.jpg"
export {default as feature8} from "../../../assets/images/features/feature-08.jpg"
export {default as feature9} from "../../../assets/images/features/feature-09.jpg"
export {default as feature10} from "../../../assets/images/features/feature-10.jpg"
export {default as feature11} from "../../../assets/images/features/feature-11.jpg"
export {default as feature12} from "../../../assets/images/features/feature-12.jpg"
export {default as specialities1} from "../../../assets/images/specialities/specialities-01.png"
export {default as specialities2} from "../../../assets/images/specialities/specialities-02.png"
export {default as specialities3} from "../../../assets/images/specialities/specialities-03.png"
export {default as specialities4} from "../../../assets/images/specialities/specialities-04.png"
export {default as specialities5} from "../../../assets/images/specialities/specialities-05.png"
export {default as patient1} from "../../../assets/images/patients/patient1.jpg"
export {default as patient2} from "../../../assets/images/patients/patient2.jpg"
export {default as patient3} from "../../../assets/images/patients/patient3.jpg"
export {default as patient4} from "../../../assets/images/patients/patient4.jpg"


export {default as aboutimg1} from "../../../assets/images/about-img1.jpg"
export {default as aboutimg2} from "../../../assets/images/about-img2.jpg"
export {default as aboutimg3} from "../../../assets/images/about-img3.jpg"
export {default as shape06} from "../../../assets/images/shape-06.png"
export {default as shape07} from "../../../assets/images/shape-07.png"
export {default as shape04} from "../../../assets/images/shape-04.png"
export {default as shape05} from "../../../assets/images/shape-05.png"
export {default as wayimg} from "../../../assets/images/way-img.png"
export {default as faqimg} from "../../../assets/images/faq-img.png"
export {default as phoneicon} from "../../../assets/images/icons/phone-icon.svg"
export {default as choose01} from "../../../assets/images/icons/choose-01.svg"
export {default as choose02} from "../../../assets/images/icons/choose-02.svg"
export {default as choose03} from "../../../assets/images/icons/choose-03.svg"
export {default as choose04} from "../../../assets/images/icons/choose-04.svg"
export {default as smilingicon} from "../../../assets/images/icons/smiling-icon.svg"
export {default as doctor03} from "../../../assets/images/doctors/doctor-03.jpg"
export {default as doctor04} from "../../../assets/images/doctors/doctor-04.jpg"
export {default as doctor05} from "../../../assets/images/doctors/doctor-05.jpg"
export {default as doctor02} from "../../../assets/images/doctors/doctor-02.jpg"
export {default as client01} from "../../../assets/images/clients/client-01.jpg"
export {default as client02} from "../../../assets/images/clients/client-02.jpg"
export {default as client03} from "../../../assets/images/clients/client-03.jpg"
export {default as client04} from "../../../assets/images/clients/client-04.jpg"
export {default as client05} from "../../../assets/images/clients/client-05.jpg"
// export { default as experience_4 } from "../assets/images/icons/experience-4.png";
// export { default as experience_5 } from "../assets/images/icons/experience-5.png";
// export { default as experience_6 } from "../assets/images/icons/experience-6.png";
// export { default as health_care_1 } from "../assets/images/icons/health-care-1.png";
