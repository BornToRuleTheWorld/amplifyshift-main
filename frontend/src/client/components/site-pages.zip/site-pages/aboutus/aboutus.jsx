/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import Header from "../../header";
import Footer from "../../footer";
import SiteHeader from "../home/header";
import {
  vect1,
  vect2,
  vect3,
  feature7,
  feature8,
  feature9,
  feature10,
  feature11,
  feature12,
  specialities1,
  specialities2,
  specialities3,
  specialities4,
  specialities5,
  patient1,
  patient2,
  patient3,
  patient4,
  aboutimg1,
  aboutimg2,
  aboutimg3,
  phoneicon,
  choose01,
  choose02,
  choose03,
  choose04,
  smilingicon,
  shape06,
  shape07,
  wayimg,
  doctor03,
  doctor04,
  doctor05,
  doctor02,
  shape04,
  shape05,
  client01,
  client02,
  client03,
  client04,
  client05,
  faqimg,
} from "../aboutus/img";
import CountUp from "react-countup";
import ImageWithBasePath from "../../../../core/img/imagewithbasebath";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";


const SiteAboutUS = (props) => {
  let pathname = props.location.pathname;

  if (props.location.pathname === "/pages/aboutus") {
    require("../../../assets/css/feather.css");
  }

  useEffect(() => {
    document.body.classList.add("about-page");

    return () => document.body.classList.remove("about-page");
  }, []);

  const settings = {
    dots: false,
    autoplay: false,
    infinite: true,
    speed: 2000,
    variableWidth: false,
    slidesToShow: 1,
    slidesToScroll: 1,
    swipeToSlide: true,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 500,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  return (
    <>
      <SiteHeader {...props} />
      <>
        <>
          {/* Breadcrumb */}
          <div className="breadcrumb-bar">
            <div className="container">
              <div className="row align-items-center inner-banner">
                <div className="col-md-12 col-12 text-center">
                  <nav aria-label="breadcrumb" className="page-breadcrumb">
                    <ol className="breadcrumb">
                      <li className="breadcrumb-item">
                        <a href="/home">
                          <i className="isax isax-home-15" />
                        </a>
                      </li>
                      <li className="breadcrumb-item active">About Us</li>
                    </ol>
                    <h2 className="breadcrumb-title">About Us</h2>
                  </nav>
                </div>
              </div>
            </div>
            <div className="breadcrumb-bg">
              <ImageWithBasePath
                src="assets/img/bg/breadcrumb-bg-01.png"
                alt="img"
                className="breadcrumb-bg-01"
              />
              <ImageWithBasePath
                src="assets/img/bg/breadcrumb-bg-02.png"
                alt="img"
                className="breadcrumb-bg-02"
              />
              <ImageWithBasePath
                src="assets/img/bg/breadcrumb-icon.png"
                alt="img"
                className="breadcrumb-bg-03"
              />
              <ImageWithBasePath
                src="assets/img/bg/breadcrumb-icon.png"
                alt="img"
                className="breadcrumb-bg-04"
              />
            </div>
          </div>
          {/* /Breadcrumb */}
        </>

        {/* About Us */}
        <section className="about-section">
          <div className="container">
            <div className="row align-items-center">
              <div className="col-lg-6 col-md-12">
                <div className="about-img-info">
                  <div className="row">
                    <div className="col-md-6">
                      <div className="about-inner-img">
                        <div className="about-img">
                          <img src={aboutimg1} className="img-fluid" alt="" />
                        </div>
                        <div className="about-img">
                          <img src={aboutimg2} className="img-fluid" alt="" />
                        </div>
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="about-inner-img">
                        <div className="about-box">
                          <h4>Over 25+ Years Experience</h4>
                        </div>
                        <div className="about-img">
                          <img src={aboutimg3} className="img-fluid" alt="" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-6 col-md-12">
                <div className="section-inner-header about-inner-header">
                  <h6>About Our Company</h6>
                  <h2>
                    We Are Always Ensure Best Medical Treatment For Your Health
                  </h2>
                </div>
                <div className="about-content">
                  <div className="about-content-details">
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                      sed do eiusmod tempor incididunt ut labore et dolore magna
                      aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                      ullamco laboris nisi ut aliquip ex ea commodo consequat.
                      Duis aute irure dolor in reprehenderit in voluptate velit
                      esse cillum dolore eu fugiat nulla pariatur.
                    </p>
                    <p>
                      Sed ut perspiciatis unde omnis iste natus sit voluptatem
                      accusantium doloremque eaque ipsa quae architecto beatae
                      vitae dicta sunt explicabo.
                    </p>
                  </div>
                  <div className="about-contact">
                    <div className="about-contact-icon">
                      <span>
                        <img src={phoneicon} alt="" />
                      </span>
                    </div>
                    <div className="about-contact-text">
                      <p>Need Emergency?</p>
                      <h4>+1 315 369 5943</h4>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* /About Us */}
        {/* Why Choose Us */}
        <section className="why-choose-section">
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                <div className="section-inner-header text-center">
                  <h2>Why Choose Us</h2>
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-lg-3 col-md-6 d-flex">
                <div className="card why-choose-card w-100">
                  <div className="card-body">
                    <div className="why-choose-icon">
                      <span>
                        <img src={choose01} alt="" />
                      </span>
                    </div>
                    <div className="why-choose-content">
                      <h4>Qualified Staff of Doctors</h4>
                      <p>
                        Lorem ipsum sit amet consectetur incididunt ut labore et
                        exercitation ullamco laboris nisi dolore magna enim
                        veniam aliqua.{" "}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-3 col-md-6 d-flex">
                <div className="card why-choose-card w-100">
                  <div className="card-body">
                    <div className="why-choose-icon">
                      <span>
                        <img src={choose02} alt="" />
                      </span>
                    </div>
                    <div className="why-choose-content">
                      <h4>Qualified Staff of Doctors</h4>
                      <p>
                        Lorem ipsum sit amet consectetur incididunt ut labore et
                        exercitation ullamco laboris nisi dolore magna enim
                        veniam aliqua.{" "}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-3 col-md-6 d-flex">
                <div className="card why-choose-card w-100">
                  <div className="card-body">
                    <div className="why-choose-icon">
                      <span>
                        <img src={choose03} alt="" />
                      </span>
                    </div>
                    <div className="why-choose-content">
                      <h4>Qualified Staff of Doctors</h4>
                      <p>
                        Lorem ipsum sit amet consectetur incididunt ut labore et
                        exercitation ullamco laboris nisi dolore magna enim
                        veniam aliqua.{" "}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-3 col-md-6 d-flex">
                <div className="card why-choose-card w-100">
                  <div className="card-body">
                    <div className="why-choose-icon">
                      <span>
                        <img src={choose04} alt="" />
                      </span>
                    </div>
                    <div className="why-choose-content">
                      <h4>Qualified Staff of Doctors</h4>
                      <p>
                        Lorem ipsum sit amet consectetur incididunt ut labore et
                        exercitation ullamco laboris nisi dolore magna enim
                        veniam aliqua.{" "}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* /Why Choose Us */}
        {/* Way Section */}
        <section className="way-section">
          <div className="container">
            <div className="way-bg">
              <div className="way-shapes-img">
                <div className="way-shapes-left">
                  <img src={shape06} alt="" />
                </div>
                <div className="way-shapes-right">
                  <img src={shape07} alt="" />
                </div>
              </div>
              <div className="row align-items-end">
                <div className="col-lg-7 col-md-12">
                  <div className="section-inner-header way-inner-header mb-0">
                    <h2>Be on Your Way to Feeling Better with the Doccure</h2>
                    <p>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                      sed do eiusmod tempor incididunt ut labore et dolore magna
                      aliqua.
                    </p>
                    <Link to="/contactus" className="btn btn-primary">
                      Contact With Us
                    </Link>
                  </div>{" "}
                </div>
                <div className="col-lg-5 col-md-12">
                  <div className="way-img">
                    <img src={wayimg} className="img-fluid" alt="" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* /Way Choose Us */}
        {/* Doctors Section */}
        <section className="doctors-section professional-section">
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                <div className="section-inner-header text-center">
                  <h2>Best Doctors</h2>
                </div>
              </div>
            </div>
            <div className="row">
              {/* Doctor Item */}
              <div className="col-lg-3 col-md-6 d-flex">
                <div className="doctor-profile-widget w-100">
                  <div className="doc-pro-img">
                    <Link to="/patient/doctor-profile">
                      <div className="doctor-profile-img">
                        <img src={doctor03} className="img-fluid" alt="" />
                      </div>
                    </Link>
                    <div className="doctor-amount">
                      <span>$ 200</span>
                    </div>
                  </div>
                  <div className="doc-content">
                    <div className="doc-pro-info">
                      <div className="doc-pro-name">
                        <Link to="/patient/doctor-profile">
                          Dr. Ruby Perrin
                        </Link>
                        <p>Cardiology</p>
                      </div>
                      <div className="reviews-ratings">
                        <p>
                          <span>
                            <i className="fas fa-star" /> 4.5
                          </span>{" "}
                          (35)
                        </p>
                      </div>
                    </div>
                    <div className="doc-pro-location">
                      <p>
                        <i className="feather-map-pin" /> Newyork, USA
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              {/* /Doctor Item */}
              {/* Doctor Item */}
              <div className="col-lg-3 col-md-6 d-flex">
                <div className="doctor-profile-widget w-100">
                  <div className="doc-pro-img">
                    <Link to="/patient/doctor-profile">
                      <div className="doctor-profile-img">
                        <img src={doctor04} className="img-fluid" alt="" />
                      </div>
                    </Link>
                    <div className="doctor-amount">
                      <span>$ 360</span>
                    </div>
                  </div>
                  <div className="doc-content">
                    <div className="doc-pro-info">
                      <div className="doc-pro-name">
                        <Link to="/patient/doctor-profile">
                          Dr. Darren Elder
                        </Link>
                        <p>Neurology</p>
                      </div>
                      <div className="reviews-ratings">
                        <p>
                          <span>
                            <i className="fas fa-star" /> 4.0
                          </span>{" "}
                          (20)
                        </p>
                      </div>
                    </div>
                    <div className="doc-pro-location">
                      <p>
                        <i className="feather-map-pin" /> Florida, USA
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              {/* /Doctor Item */}
              {/* Doctor Item */}
              <div className="col-lg-3 col-md-6 d-flex">
                <div className="doctor-profile-widget w-100">
                  <div className="doc-pro-img">
                    <Link to="/patient/doctor-profile">
                      <div className="doctor-profile-img">
                        <img src={doctor05} className="img-fluid" alt="" />
                      </div>
                    </Link>
                    <div className="doctor-amount">
                      <span>$ 450</span>
                    </div>
                  </div>
                  <div className="doc-content">
                    <div className="doc-pro-info">
                      <div className="doc-pro-name">
                        <Link to="/patient/doctor-profile">
                          Dr. Sofia Brient
                        </Link>
                        <p>Urology</p>
                      </div>
                      <div className="reviews-ratings">
                        <p>
                          <span>
                            <i className="fas fa-star" /> 4.5
                          </span>{" "}
                          (30)
                        </p>
                      </div>
                    </div>
                    <div className="doc-pro-location">
                      <p>
                        <i className="feather-map-pin" /> Georgia, USA
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              {/* /Doctor Item */}
              {/* Doctor Item */}
              <div className="col-lg-3 col-md-6 d-flex">
                <div className="doctor-profile-widget w-100">
                  <div className="doc-pro-img">
                    <Link to="/patient/doctor-profile">
                      <div className="doctor-profile-img">
                        <img src={doctor02} className="img-fluid" alt="" />
                      </div>
                    </Link>
                    <div className="doctor-amount">
                      <span>$ 570</span>
                    </div>
                  </div>
                  <div className="doc-content">
                    <div className="doc-pro-info">
                      <div className="doc-pro-name">
                        <Link to="/patient/doctor-profile">
                          Dr. Paul Richard
                        </Link>
                        <p>Orthopedic</p>
                      </div>
                      <div className="reviews-ratings">
                        <p>
                          <span>
                            <i className="fas fa-star" /> 4.3
                          </span>{" "}
                          (45)
                        </p>
                      </div>
                    </div>
                    <div className="doc-pro-location">
                      <p>
                        <i className="feather-map-pin" /> Michigan, USA
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              {/* /Doctor Item */}
            </div>
          </div>
        </section>
        {/* /Doctors Section */}
        {/* Testimonial Section */}
        <section className="testimonial-section">
          <div className="testimonial-shape-img">
            <div className="testimonial-shape-left">
              <ImageWithBasePath src="assets/img/shape-04.png" alt="shape-image" />
            </div>
            <div className="testimonial-shape-right">
              <ImageWithBasePath src="assets/img/shape-05.png" alt="shape-image" />
            </div>
          </div>
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                <div className="testimonial-slider slick">
                  <Slider {...settings}>
                    <div className="testimonial-grid">
                      <div className="testimonial-info">
                        <div className="testimonial-img">
                          <ImageWithBasePath
                            src="assets/img/clients/client-01.jpg"
                            className="img-fluid"
                            alt="client-image"
                          />
                        </div>
                        <div className="testimonial-content">
                          <div className="section-inner-header testimonial-header">
                            <h6>Testimonials</h6>
                            <h2>What Our Client Says</h2>
                          </div>
                          <div className="testimonial-details">
                            <p>
                              Doccure exceeded my expectations in healthcare. The seamless
                              booking process, coupled with the expertise of the doctors,
                              made my experience exceptional. Their commitment to quality
                              care and convenience truly sets them apart. I highly
                              recommend Doccure for anyone seeking reliable and accessible
                              healthcare services..
                            </p>
                            <h6>
                              <span>John Doe</span> New York
                            </h6>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="testimonial-grid">
                      <div className="testimonial-info">
                        <div className="testimonial-img">
                          <ImageWithBasePath
                            src="assets/img/clients/client-02.jpg"
                            className="img-fluid"
                            alt="client-image"
                          />
                        </div>
                        <div className="testimonial-content">
                          <div className="section-inner-header testimonial-header">
                            <h6>Testimonials</h6>
                            <h2>What Our Client Says</h2>
                          </div>
                          <div className="testimonial-details">
                            <p>
                              Doccure exceeded my expectations in healthcare. The seamless
                              booking process, coupled with the expertise of the doctors,
                              made my experience exceptional. Their commitment to quality
                              care and convenience truly sets them apart. I highly
                              recommend Doccure for anyone seeking reliable and accessible
                              healthcare services..
                            </p>
                            <h6>
                              <span>Amanda Warren</span> Florida
                            </h6>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="testimonial-grid">
                      <div className="testimonial-info">
                        <div className="testimonial-img">
                          <ImageWithBasePath
                            src="assets/img/clients/client-03.jpg"
                            className="img-fluid"
                            alt="client-image"
                          />
                        </div>
                        <div className="testimonial-content">
                          <div className="section-inner-header testimonial-header">
                            <h6>Testimonials</h6>
                            <h2>What Our Client Says</h2>
                          </div>
                          <div className="testimonial-details">
                            <p>
                              Doccure exceeded my expectations in healthcare. The seamless
                              booking process, coupled with the expertise of the doctors,
                              made my experience exceptional. Their commitment to quality
                              care and convenience truly sets them apart. I highly
                              recommend Doccure for anyone seeking reliable and accessible
                              healthcare services..
                            </p>
                            <h6>
                              <span>Betty Carlson</span> Georgia
                            </h6>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="testimonial-grid">
                      <div className="testimonial-info">
                        <div className="testimonial-img">
                          <ImageWithBasePath
                            src="assets/img/clients/client-04.jpg"
                            className="img-fluid"
                            alt="client-image"
                          />
                        </div>
                        <div className="testimonial-content">
                          <div className="section-inner-header testimonial-header">
                            <h6>Testimonials</h6>
                            <h2>What Our Client Says</h2>
                          </div>
                          <div className="testimonial-details">
                            <p>
                              Doccure exceeded my expectations in healthcare. The seamless
                              booking process, coupled with the expertise of the doctors,
                              made my experience exceptional. Their commitment to quality
                              care and convenience truly sets them apart. I highly
                              recommend Doccure for anyone seeking reliable and accessible
                              healthcare services..
                            </p>
                            <h6>
                              <span>Veronica</span> California
                            </h6>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="testimonial-grid">
                      <div className="testimonial-info">
                        <div className="testimonial-img">
                          <ImageWithBasePath
                            src="assets/img/clients/client-05.jpg"
                            className="img-fluid"
                            alt="client-image"
                          />
                        </div>
                        <div className="testimonial-content">
                          <div className="section-inner-header testimonial-header">
                            <h6>Testimonials</h6>
                            <h2>What Our Client Says</h2>
                          </div>
                          <div className="testimonial-details">
                            <p>
                              Doccure exceeded my expectations in healthcare. The seamless
                              booking process, coupled with the expertise of the doctors,
                              made my experience exceptional. Their commitment to quality
                              care and convenience truly sets them apart. I highly
                              recommend Doccure for anyone seeking reliable and accessible
                              healthcare services..
                            </p>
                            <h6>
                              <span>Richard</span> Michigan
                            </h6>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Slider>

                </div>
              </div>
            </div>
          </div>
        </section>

        {/* /Testimonial Section */}
        {/* FAQ Section */}
        <section className="faq-section faq-section-inner">
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                <div className="section-inner-header text-center">
                  <h6>Get Your Answer</h6>
                  <h2>Frequently Asked Questions</h2>
                </div>
              </div>
            </div>
            <div className="row align-items-center">
              <div className="col-lg-6 col-md-12">
                <div className="faq-img">
                  <img src={faqimg} className="img-fluid" alt="img" />
                  <div className="faq-patients-count">
                    <div className="faq-smile-img">
                      <img src={smilingicon} alt="icon" />
                    </div>
                    <div className="faq-patients-content">
                      <h4>
                        <span className="count-digit">
                          <CountUp start={1} end={95} />
                        </span>
                        k+
                      </h4>
                      <p>Happy Patients</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-6 col-md-12">
                <div className="faq-info">
                  <div className="accordion" id="accordionExample">
                    {/* FAQ Item */}
                    <div className="accordion-item">
                      <h2 className="accordion-header" id="headingOne">
                        <Link
                          to="#"
                          className="accordion-button"
                          data-bs-toggle="collapse"
                          data-bs-target="#collapseOne"
                          aria-expanded="true"
                          aria-controls="collapseOne"
                        >
                          Can i make an Appointment Online with White Plains
                          Hospital Kendi?
                        </Link>
                      </h2>
                      <div
                        id="collapseOne"
                        className="accordion-collapse collapse show"
                        aria-labelledby="headingOne"
                        data-bs-parent="#accordionExample"
                      >
                        <div className="accordion-body">
                          <div className="accordion-content">
                            <p>
                              Lorem ipsum dolor sit amet, consectetur adipiscing
                              elit, sed do eiusmod tempor incididunt ut labore
                              et dolore magna aliqua. Ut enim ad minim veniam,{" "}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    {/* /FAQ Item */}
                    {/* FAQ Item */}
                    <div className="accordion-item">
                      <h2 className="accordion-header" id="headingTwo">
                        <Link
                          to="#"
                          className="accordion-button collapsed"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#collapseTwo"
                          aria-expanded="false"
                          aria-controls="collapseTwo"
                        >
                          Can i make an Appointment Online with White Plains
                          Hospital Kendi?
                        </Link>
                      </h2>
                      <div
                        id="collapseTwo"
                        className="accordion-collapse collapse"
                        aria-labelledby="headingTwo"
                        data-bs-parent="#accordionExample"
                      >
                        <div className="accordion-body">
                          <div className="accordion-content">
                            <p>
                              Lorem ipsum dolor sit amet, consectetur adipiscing
                              elit, sed do eiusmod tempor incididunt ut labore
                              et dolore magna aliqua. Ut enim ad minim veniam,{" "}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    {/* /FAQ Item */}
                    {/* FAQ Item */}
                    <div className="accordion-item">
                      <h2 className="accordion-header" id="headingThree">
                        <Link
                          to="#"
                          className="accordion-button collapsed"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#collapseThree"
                          aria-expanded="false"
                          aria-controls="collapseThree"
                        >
                          Can i make an Appointment Online with White Plains
                          Hospital Kendi?
                        </Link>
                      </h2>
                      <div
                        id="collapseThree"
                        className="accordion-collapse collapse"
                        aria-labelledby="headingThree"
                        data-bs-parent="#accordionExample"
                      >
                        <div className="accordion-body">
                          <div className="accordion-content">
                            <p>
                              Lorem ipsum dolor sit amet, consectetur adipiscing
                              elit, sed do eiusmod tempor incididunt ut labore
                              et dolore magna aliqua. Ut enim ad minim veniam,{" "}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    {/* /FAQ Item */}
                    {/* FAQ Item */}
                    <div className="accordion-item">
                      <h2 className="accordion-header" id="headingFour">
                        <Link
                          to="#"
                          className="accordion-button collapsed"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#collapseFour"
                          aria-expanded="false"
                          aria-controls="collapseFour"
                        >
                          Can i make an Appointment Online with White Plains
                          Hospital Kendi?
                        </Link>
                      </h2>
                      <div
                        id="collapseFour"
                        className="accordion-collapse collapse"
                        aria-labelledby="headingFour"
                        data-bs-parent="#accordionExample"
                      >
                        <div className="accordion-body">
                          <div className="accordion-content">
                            <p>
                              Lorem ipsum dolor sit amet, consectetur adipiscing
                              elit, sed do eiusmod tempor incididunt ut labore
                              et dolore magna aliqua. Ut enim ad minim veniam,{" "}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    {/* /FAQ Item */}
                    {/* FAQ Item */}
                    <div className="accordion-item">
                      <h2 className="accordion-header" id="headingFive">
                        <Link
                          to="#"
                          className="accordion-button collapsed"
                          type="button"
                          data-bs-toggle="collapse"
                          data-bs-target="#collapseFive"
                          aria-expanded="false"
                          aria-controls="collapseFive"
                        >
                          Can i make an Appointment Online with White Plains
                          Hospital Kendi?
                        </Link>
                      </h2>
                      <div
                        id="collapseFive"
                        className="accordion-collapse collapse"
                        aria-labelledby="headingFive"
                        data-bs-parent="#accordionExample"
                      >
                        <div className="accordion-body">
                          <div className="accordion-content">
                            <p>
                              Lorem ipsum dolor sit amet, consectetur adipiscing
                              elit, sed do eiusmod tempor incididunt ut labore
                              et dolore magna aliqua. Ut enim ad minim veniam,{" "}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    {/* /FAQ Item */}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* /FAQ Section */}
      </>

      <Footer {...props} />
    </>
  );
};

export default SiteAboutUS;
